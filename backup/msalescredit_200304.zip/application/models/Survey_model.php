<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Survey_model extends CI_Model
{

    public $table1 = 'survey';
    public $table = 'survey_lists';
    public $id = 'sv_no';
    public $order = 'DESC';
    private $db_jmb;

    function __construct()
    {
        parent::__construct();
        $this->db_jmb = $this->load->database('jmb', TRUE);
    }

    function get_team()
    {
      $this->db_jmb->select('sgm_code,sgm_account');
      $this->db_jmb->where('sgm_code!=', 'TL_JMB');
      $this->db_jmb->where('sgm_code!=', 'SPV_TL_JMB');
      $this->db_jmb->order_by('sgm_account', $this->order);
      return $this->db_jmb->get('salesmangroup_masters')->result();
    }

    function get_svno($svno)
    {
      $this->db_jmb->select('sv_date,sv_result,cust_name,slm_name,itm_name,cl_name,sv_dpsetor,fc_code,sv_no,sv_plandate,leader,allproc');
      $this->db_jmb->where('sv_no', $svno);
      $this->db_jmb->where('ori_code', 'JMB');
      $this->db_jmb->order_by('modi_date', $this->order);
      return $this->db_jmb->get($this->table)->result();
    }

    function get_status($date,$status,$team)
    {
      $tgl = explode("-", $date);
      $this->db_jmb->select('sv_date,sv_result,cust_name,slm_name,itm_name,cl_name,sv_dpsetor,fc_code,sv_no,sv_plandate,leader');
      $this->db_jmb->where("date_part('year', sv_date)=", $tgl[0]);
      $this->db_jmb->where("date_part('month', sv_date)=", $tgl[1]);
      $this->db_jmb->where('sv_result', $status);
      $this->db_jmb->where('ori_code', 'JMB');
      if($team!='ALL'){
        $this->db_jmb->where('sgm_code', $team);
      }
      $this->db_jmb->order_by('modi_date', $this->order);
      return $this->db_jmb->get($this->table)->result();
    }

    function get_count_status($date,$status,$team)
    {
      $tgl = explode("-", $date);
      $this->db_jmb->where("date_part('year', sv_date)=", $tgl[0]);
      $this->db_jmb->where("date_part('month', sv_date)=", $tgl[1]);
      $this->db_jmb->where('sv_result', $status);
      $this->db_jmb->where('ori_code', 'JMB');
      if($team!='ALL'){
        $this->db_jmb->where('sgm_code', $team);
      }
      return $this->db_jmb->count_all_results($this->table);
    }

    function get_do($date,$team)
    {
      $tgl = explode("-", $date);
      $this->db_jmb->select('sv_date,sv_result,cust_name,slm_name,itm_name,cl_name,sv_dpsetor,fc_code,sv_no,sv_plandate,leader,allproc');
      $this->db_jmb->where("date_part('year', sv_date)=", $tgl[0]);
      $this->db_jmb->where("date_part('month', sv_date)=", $tgl[1]);
      $this->db_jmb->where('sv_result', 'ACC');
      $this->db_jmb->where('astate', '1');
      $this->db_jmb->where('ori_code', 'JMB');
      if($team!='ALL'){
        $this->db_jmb->where('sgm_code', $team);
      }
      $this->db_jmb->order_by('modi_date', $this->order);
      return $this->db_jmb->get('sales_credit_lists')->result();
    }

    function get_count_do($date,$team)
    {
      $tgl = explode("-", $date);
      $this->db_jmb->where("date_part('year', sv_date)=", $tgl[0]);
      $this->db_jmb->where("date_part('month', sv_date)=", $tgl[1]);
      $this->db_jmb->where('sv_result', 'ACC');
      $this->db_jmb->where('astate', '1');
      $this->db_jmb->where('ori_code', 'JMB');
      if($team!='ALL'){
        $this->db_jmb->where('sgm_code', $team);
      }
      return $this->db_jmb->count_all_results('sales_credit_lists');
    }

    function get_acc($date,$team)
    {
      $tgl = explode("-", $date);
      $this->db_jmb->select('sv_date,sv_result,cust_name,slm_name,itm_name,cl_name,sv_dpsetor,fc_code,sv_no,sv_plandate,leader,allproc');
      $this->db_jmb->where("date_part('year', sv_date)=", $tgl[0]);
      $this->db_jmb->where("date_part('month', sv_date)=", $tgl[1]);
      $this->db_jmb->where('sv_result', 'ACC');
      $this->db_jmb->where('astate', '0');
      $this->db_jmb->where('ori_code', 'JMB');
      if($team!='ALL'){
        $this->db_jmb->where('sgm_code', $team);
      }
      $this->db_jmb->order_by('modi_date', $this->order);
      return $this->db_jmb->get('sales_credit_lists')->result();
    }

    function get_count_acc($date,$team)
    {
      $tgl = explode("-", $date);
      $this->db_jmb->where("date_part('year', sv_date)=", $tgl[0]);
      $this->db_jmb->where("date_part('month', sv_date)=", $tgl[1]);
      $this->db_jmb->where('sv_result', 'ACC');
      $this->db_jmb->where('astate', '0');
      $this->db_jmb->where('ori_code', 'JMB');
      if($team!='ALL'){
        $this->db_jmb->where('sgm_code', $team);
      }
      return $this->db_jmb->count_all_results('sales_credit_lists');
    }


    function get_all()
    {
      $this->db->select('sv_date,sv_result,cust_name,slm_name,itm_name,cl_name,sv_dpsetor,fc_code,sv_no,sv_plandate,leader');
        //$this->db_jmb->where('sv_date', '2020-01-02');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db_jmb->where($this->id, $id);
        return $this->db_jmb->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db_jmb->like('sv_id', $q);
	$this->db_jmb->or_like('sv_no', $q);
	$this->db_jmb->or_like('cust_code', $q);
	$this->db_jmb->or_like('slm_code', $q);
	$this->db_jmb->or_like('sv_result', $q);
	$this->db_jmb->or_like('cust_name', $q);
	$this->db_jmb->or_like('cust_idcardno', $q);
	$this->db_jmb->from($this->table);
        return $this->db_jmb->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db_jmb->order_by($this->id, $this->order);
        $this->db_jmb->like('sv_id', $q);
	$this->db_jmb->or_like('sv_no', $q);
	$this->db_jmb->or_like('cust_code', $q);
	$this->db_jmb->or_like('slm_code', $q);
	$this->db_jmb->or_like('sv_result', $q);
	$this->db_jmb->or_like('cust_name', $q);
	$this->db_jmb->or_like('cust_idcardno', $q);
	$this->db_jmb->limit($limit, $start);
        return $this->db_jmb->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db_jmb->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db_jmb->where($this->id, $id);
        $this->db_jmb->update($this->table1, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db_jmb->where($this->id, $id);
        $this->db_jmb->delete($this->table);
    }

}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-08-16 13:59:02 */
/* http://harviacode.com */