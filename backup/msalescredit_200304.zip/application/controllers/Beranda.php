<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Beranda extends CI_Controller
{
    
        
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Survey_model','Comment_model','History_model'));
        if($this->session->userdata('user_logedin') != 'TRUE'){ redirect('login', 'refresh');}
    }

    function get_team(){
      $data = $this->Survey_model->get_team();
      echo json_encode($data);
    }

    function history_update(){
      $id = $this->input->post('id');
      $data = array('text' => $this->input->post('text'));

      $this->History_model->update($id,$data);
      echo json_encode(array('svno'=>$data,'pesan'=>'sukses'));
    }

    function history_save(){
      $svno = $this->input->post('svno');

      $data = array(
        'sv_no' => $svno,
        'text' => $this->input->post('text'),
        'status' => $this->input->post('status'),
        'user_id' => $this->input->post('userid')
        );
     
      $survey = array('sv_result' => $this->input->post('status'));
      $this->Survey_model->update($svno,$survey);
      $this->History_model->insert($data);
      echo json_encode(array('svno'=>$data,'pesan'=>'sukses'));
    }

    function card_update(){
      $id = $this->input->post('id');
      $data = array('text' => $this->input->post('text'));

      $this->History_model->update($id,$data);
      echo json_encode(array('svno'=>$data,'pesan'=>'sukses'));
    }

    function data_history($svno){
      $data = $this->History_model->get_svno($svno);
      echo json_encode($data);
    }

    function get_history($svno){
      $data = $this->History_model->get_svno($svno);
      echo json_encode($data);
    }

    function history_count($svno,$status){
      $data = array('count'=>$this->History_model->get_count($svno,$status));
      echo json_encode($data);
    }

    function comment_save(){
      $svno = $this->input->post('svno');

      $data = array(
        'sv_no' => $svno,
        'text' => $this->input->post('text'),
        'category' => $this->input->post('status'),
        'user_id' => $this->input->post('userid')
        );

      $this->Comment_model->insert($data);

      echo json_encode(array('svno'=>$svno,'pesan'=>'sukses'));
    }

    function data_comment($svno,$status){
      $data = $this->Comment_model->get_svno($svno);
      echo json_encode($data);
    }

    function comment_count($svno){
      $data = array('count'=>$this->Comment_model->get_count($svno));
      echo json_encode($data);
    }

    function data_svno($svno){
      $data = $this->Survey_model->get_svno($svno);
      echo json_encode($data);
    }

    function count($date,$team){
      $count_acc = $this->Survey_model->get_count_acc($date,$team);
      $count_tolak = $this->Survey_model->get_count_status($date,'DITOLAK',$team);
      $count_batal = $this->Survey_model->get_count_status($date,'CANCEL',$team);
      $count_pending = $this->Survey_model->get_count_status($date,'PENDING',$team);
      $count_process = $this->Survey_model->get_count_status($date,'PROGRESS',$team);
      $count_do = $this->Survey_model->get_count_do($date,$team);
      $data = array(
          'acc'=>$count_acc,
          'batal'=>$count_batal,
          'tolak'=>$count_tolak,
          'pending'=>$count_pending,
          'process'=>$count_process,
          'do'=>$count_do,
        );
      echo json_encode($data);
    }

    function data_card($date=null,$team=null){
      $data = array(
        'pending'=>$this->Survey_model->get_status($date,'PENDING',$team),
        'progress'=>$this->Survey_model->get_status($date,'PROGRESS',$team),
        'tolak'=>$this->Survey_model->get_status($date,'DITOLAK',$team),
        'acc'=>$this->Survey_model->get_acc($date,$team),
        'do'=>$this->Survey_model->get_do($date,$team),
        'batal'=>$this->Survey_model->get_status($date,'CANCEL',$team)

      );
    
    echo json_encode($data);
  }

    function data_status($date=null,$status=null){
      if($status != 'DO'){
        $data=$this->Survey_model->get_status($date,$status);
      }else{
        $data=$this->Survey_model->get_do($date,$status);
      }
    
    echo json_encode($data);
  }


    function index(){
      $this->template->load('template','beranda');
    }


    public function sample()
    {
     
      $this->template->load('template','beranda_sample');
    }
}