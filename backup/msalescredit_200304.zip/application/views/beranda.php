  <!-- Main content -->
      <section class="content">
        <!-- penampilan total record -->
        <div class="row">
          <div class='col-lg-12'>
        	<div class="callout callout-success">
                <h4>Selamat Datang di M-Sales Credit</h4>
              </div>
          </div>
        </div>
        <div class="row">
        <div class='col-sm-2'>
            <div class="form-group">
                <div class='input-group date' id='date1'>
                    <input type='text' id='tgl' value="<?php echo date('Y-m-d') ?> " class="form-control" placeholder="Start Date"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group row">
              <div id="selectTeam">
                <h4 for="exampleFormControlSelect1" class="col-sm-2 box-title">Team</h4>
                <div class="col-sm-2" style="padding-left: 1px; padding-right: 1px;">
                  <select id="team" name="team" class="form-control col-sm-2">
                  </select>
                </div>
              </div>
              <div class="col-sm-2">
                  <button  id="mySearch" class="btn btn-info"><i class="fa fa-search"></i></button>
              </div>
          </div>
        </div>
      </div>
      
          <div class="row" style="overflow-x: auto; padding-left: 5.4px;">
            <ul class="drag-list" style="min-width: 1200px;">
                <li class="drag-column drag-column-start">
                  <span class="drag-column-header">
                      <div class="row">
                        <div class="col-md-12">
                          <h2 style="color: white;">Belum Survey</h2>
                        </div>
                        <div class="col-md-12">
                          <h6 style="margin-right: auto; color: white;"><span class="label label-warning" style="margin-right: 7px"><f id="jml_pending_atas"></f></span><f id="jml_pending_bawah"></f> card</h6>
                        </div>
                      </div>
                    </span>
                    
                    <div class="drag-options" id="options1"></div>
                    <ul class="row drag-inner-list" id="card_pending" style="overflow-y: auto; height: calc(100vh - 200px);">
                    </ul>
                    <h6 style="text-align: center; color: gray;">Customers booking</h6>
                </li>
                <li class="drag-column drag-column-in-progress">
                  <span class="drag-column-header">
                      <div class="row">
                        <div class="col-md-12">
                          <h2 style="color: white;">Survey</h2>
                        </div>
                        <div class="col-md-12">
                          <h6 style="margin-right: auto; color: white;"><span class="label label-warning" style="margin-right: 7px"><f id="jml_process_atas"></f></span><f id="jml_process_bawah"></f> card</h6>
                        </div>
                      </div>
                    </span>

                    <div class="drag-options" id="options2"></div>
                    <ul class="row drag-inner-list" id="card_process" style="overflow-y: auto; height: calc(100vh - 200px);">
                    </ul>
                    <h6 style="text-align: center; color: gray;">Hasil survey belum keluar</h6>
                </li>
                <li class="drag-column drag-column-danger">
                  <span class="drag-column-header">
                      <div class="row">
                        <div class="col-md-12">
                          <h2 style="color: white;">DITOLAK</h2>
                        </div>
                        <div class="col-md-12">
                          <h6 style="margin-right: auto; color: white;"><span class="label label-warning" style="margin-right: 7px"><f id="jml_tolak_atas"></f></span><f id="jml_tolak_bawah"></f> card</h6>
                        </div>
                      </div>
                    </span>
                    <div class="drag-options" id="options3"></div>
                    <ul class="row drag-inner-list" id="card_tolak" style="overflow-y: auto; height: calc(100vh - 200px);">
                    </ul>
                    <h6 style="text-align: center; color: gray;">Survey yang ditolak</h6>
                </li>
                <li class="drag-column drag-column-approved">
                  <span class="drag-column-header">
                      <div class="row">
                        <div class="col-md-12">
                          <h2 style="color: white;">ACC</h2>
                        </div>
                        <div class="col-md-12">
                          <h6 style="margin-right: auto; color: white;"><span class="label label-warning" style="margin-right: 7px"><f id="jml_acc_atas"></f></span><f id="jml_acc_bawah"></f> card</h6>
                        </div>
                      </div>
                    </span>
                    
                    <div class="drag-options" id="options4"></div>
                    <ul class="row drag-inner-list" id="card_acc" style="overflow-y: auto; height: calc(100vh - 200px);">
                    </ul>
                    <h6 style="text-align: center; color: gray;">Sudah di ACC belum DO</h6>
                </li>

                <li id="list_do" class="drag-column drag-column-on-hold">
                  <span class="drag-column-header">
                      <div class="row">
                        <div class="col-md-12">
                          <h2 style="color: white;">DO</h2>
                        </div>
                        <div class="col-md-12">
                          <h6 style="margin-right: auto; color: white;"><span class="label label-warning" style="margin-right: 7px"><f id="jml_do_atas"></f></span><f id="jml_do_bawah"></f> card</h6>
                        </div>
                      </div>
                    </span>
                    <div class="drag-options" id="options5"></div>
                    <ul class="row drag-inner-list" id="card_do" style="overflow-y: auto; height: calc(100vh - 200px);">
                    </ul>
                    <h6 style="text-align: center; color: gray;">Congratulations!</h6>
                </li>
                <li id="list_batal" class="drag-column drag-column-cancel">
                  <span class="drag-column-header">
                      <div class="row">
                        <div class="col-md-12">
                          <h2 style="color: white;">Batal</h2>
                        </div>
                        <div class="col-md-12">
                          <h6 style="margin-right: auto; color: white;"><span class="label label-warning" style="margin-right: 7px"><f id="jml_batal_atas"></f></span><f id="jml_batal_bawah"></f> card</h6>
                        </div>
                      </div>
                    </span>
                    <div class="drag-options" id="options6"></div>
                    <ul class="row drag-inner-list" id="card_batal" style="overflow-y: auto; height: calc(100vh - 200px);">
                    </ul>
                    <h6 style="text-align: center; color: gray;">We can't win them all...</h6>
                </li>
            </ul>
          </div>

                  <!-- start ModalListBelumSurvey dan Survey-->
                  <div class="modal fade" id="ModalList" tabindex="-1" role="dialog" aria-labelledby="ModalListLabel">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Card Details</h4>
                            <h1 class="modal-title" style="color: #6093ca;"><f id="svno"></f> | <f id="status"></f></h1>
                            <h4 class="modal-title" style="color: gray;">Created by Angga Pramana Putra on Feb 25, 2020 10:36 AM</h4>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Initial Form</label>
                            <div class="badge">
                              <div style="margin: 20px;">
                                <div class="form-group">
                                  <label class="control-label label-modal">Customer Name</label><br>
                                  <label class="control-label label-gray"><f id="customer"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama Sales</label><br>
                                  <label class="control-label label-gray"><f id="sales"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama TL</label><br>
                                  <label class="control-label label-gray"><f id="leader"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">TL</label>
                                  <div class="row">
                                    <div class="col-md-1"><div class="square" style="margin-top: 5px;"></div></div>
                                    <label class="col-md-1 control-label label-gray">Dewa</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Motor</label><br>
                                  <label class="control-label label-gray"><f id="motor"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Warna</label><br>
                                  <label class="control-label label-gray"><f id="warna"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Fincoy</label><br>
                                  <label class="control-label label-gray"><f id="fincoy"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">DP</label><br>
                                  <label class="control-label label-gray"><f id="dp"></f></label>
                                </div>
                              </div>
                              </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">History</label>
                                  <div id="history_list"></div>
                                </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Comments</label>
                                  <div class="badge">
                                    <div style="margin: 20px;">
                                      <!-- start comment design -->
                                      <ul id="cm_list" class="media-list">
                                      </ul>
                                      <!-- end comment design -->
                                      <div class="form-group">
                                        <div class="row">
                                          <div class="col-md-4">
                                               <div class="form-group">
                                                  <div class="input-group">
                                                  <input id="comment" class="form-control" style="width: 450px;" />
                                                  <span class="input-group-btn">
                                                      <button id="myComment_list" class="btn btn-primary btn-block">Post
                                                      </button>
                                                  </span>
                                                  </div>
                                               </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            
                          </div>
                        </div>
                    </div>
                  </div>
                  <!-- end modal ModalListBelumSurvey dan Survey-->
                  
                  <!-- start ModalTolak-->
                  
                    <div class="modal fade" id="ModalTolak" tabindex="-1" role="dialog" aria-labelledby="ModalListLabel">
                      <div class="row">
                      <div class="col-md-6 modal-left">
                      <div class="modal-dialog modal-left" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Card Details</h4>
                            <h1 class="modal-title" style="color: #6093ca;"><f id="tolak_svno"></f> | <f id="tolak_status"></f></h1>
                            <h4 class="modal-title" style="color: gray;">Created by Angga Pramana Putra on Feb 25, 2020 10:36 AM</h4>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Initial Form</label>
                            <div class="badge">
                              <div style="margin: 20px;">
                                <div class="form-group">
                                  <label class="control-label label-modal">Customer Name</label><br>
                                  <label class="control-label label-gray"><f id="tolak_customer"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama Sales</label><br>
                                  <label class="control-label label-gray"><f id="tolak_sales"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama TL</label><br>
                                  <label class="control-label label-gray"><f id="tolak_leader"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">TL</label>
                                  <div class="row">
                                    <div class="col-md-1"><div class="square" style="margin-top: 5px;"></div></div>
                                    <label class="col-md-1 control-label label-gray">Dewa</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Motor</label><br>
                                  <label class="control-label label-gray"><f id="tolak_motor"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Warna</label><br>
                                  <label class="control-label label-gray"><f id="tolak_warna"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Fincoy</label><br>
                                  <label class="control-label label-gray"><f id="tolak_fincoy"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">DP</label><br>
                                  <label class="control-label label-gray"><f id="tolak_dp"></f></label>
                                </div>
                              </div>
                              </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">History</label>
                                  <div id="tolak_history_list"></div>
                                </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Comments</label>
                                  <div class="badge">
                                    <div style="margin: 20px;">
                                      <!-- start comment design -->
                                      <ul id="tolak_cm_list" class="media-list">
                                      </ul>
                                      <!-- end comment design -->
                                      <div class="form-group">
                                        <div class="row">
                                          <div class="col-md-4">
                                               <div class="form-group">
                                                  <div class="input-group">
                                                  <input id="tolak_comment" class="form-control" style="width: 450px;" />
                                                  <span class="input-group-btn">
                                                      <button id="myComment_tolak" class="btn btn-primary btn-block">Post
                                                      </button>
                                                  </span>
                                                  </div>
                                               </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="modal-dialog modal-right" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Current Phase</h4>
                            <h1 class="modal-title" style="color: #6093ca;">DITOLAK</h1>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Next Step</label>
                                <form>
                                  <label class="radio-inline">
                                    <input type="radio" value="Up DP" name="radioStep">Up DP
                                  </label>
                                  <label class="radio-inline">
                                    <input type="radio" value="Ganti FINCOY" name="radioStep">Ganti FINCOY
                                  </label>
                                  <label class="radio-inline">
                                    <input type="radio" value="Banding" name="radioStep">Banding
                                  </label>
                                  <label class="radio-inline">
                                    <input type="radio" value="Batal" name="radioStep">Batal
                                  </label>
                                </form>
                              <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Comment</label>
                                  <div class="form-group">
                                    <textarea placeholder="Leave your comment here" class="form-control" id="tolak_history_description" rows="3"></textarea>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button id="myHistory_tolak" type="button" class="btn btn-primary">Submit</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>
                  <!-- end ModalTolak -->

                  <!-- start ModalACC-->
                    <div class="modal fade" id="ModalAcc" tabindex="-1" role="dialog" aria-labelledby="ModalaCCLabel">
                      <div class="row">
                      <div class="col-md-6 modal-left">
                      <div class="modal-dialog modal-left" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Card Details</h4>
                            <h1 class="modal-title" style="color: #6093ca;"><f id="acc_svno"></f> | <f id="acc_status"></f></h1>
                            <h4 class="modal-title" style="color: gray;">Created by Angga Pramana Putra on Feb 25, 2020 10:36 AM</h4>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Initial Form</label>
                            <div class="badge">
                              <div style="margin: 20px;">
                                <div class="form-group">
                                  <label class="control-label label-modal">Customer Name</label><br>
                                  <label class="control-label label-gray"><f id="acc_customer"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama Sales</label><br>
                                  <label class="control-label label-gray"><f id="acc_sales"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama TL</label><br>
                                  <label class="control-label label-gray"><f id="acc_leader"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">TL</label>
                                  <div class="row">
                                    <div class="col-md-1"><div class="square" style="margin-top: 5px;"></div></div>
                                    <label class="col-md-1 control-label label-gray">Dewa</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Motor</label><br>
                                  <label class="control-label label-gray"><f id="acc_motor"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Warna</label><br>
                                  <label class="control-label label-gray"><f id="acc_warna"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Fincoy</label><br>
                                  <label class="control-label label-gray"><f id="acc_fincoy"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">DP</label><br>
                                  <label class="control-label label-gray"><f id="acc_dp"></f></label>
                                </div>
                              </div>
                              </div>
                                <div  style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">History</label>
                                  <div id="acc_history_list"></div>
                                </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Comments</label>
                                  <div class="badge">
                                    <div style="margin: 20px;">
                                      <!-- start comment design -->
                                      <ul id="acc_cm_list" class="media-list">
                                      </ul>
                                      <!-- end comment design -->
                                      <div class="form-group">
                                        <div class="row">
                                          <div class="col-md-4">
                                               <div class="form-group">
                                                  <div class="input-group">
                                                  <input id="acc_comment" class="form-control" style="width: 450px;" />
                                                  <span class="input-group-btn">
                                                      <button id="myComment_acc" class="btn btn-primary btn-block">Post
                                                      </button>
                                                  </span>
                                                  </div>
                                               </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="modal-dialog modal-right" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Current Phase</h4>
                            <h1 class="modal-title" style="color: #6093ca;">ACC</h1>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Rencana Tanggal DO</label>
                              <input id="history_id"  type='hidden' class="form-control"/>
                                <div class="form-group">
                                  <div class='input-group date' id='date2' style="color: black;">
                                    <input id="history_date"  type='text' class="form-control" placeholder="Choose Date"/>
                                    <span class="input-group-addon" >
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                              </div>
                              <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Description</label>
                                  <div class="form-group">
                                    <textarea id="history_description" placeholder="Leave your description here" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button id="myHistory_acc" type="button" class="btn btn-primary">Submit</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                  <!-- end ModalACC -->
                  <!-- start ModalDO-->
                    <div class="modal fade" id="ModalDo" tabindex="-1" role="dialog" aria-labelledby="ModalListLabel">
                      <div class="row">
                      <div class="col-md-6 modal-left">
                      <div class="modal-dialog modal-left" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Card Details</h4>
                            <h1 class="modal-title" style="color: #6093ca;"><f id="do_svno"></f> | <f id="do_status"></f></h1>
                            <h4 class="modal-title" style="color: gray;">Created by Angga Pramana Putra on Feb 25, 2020 10:36 AM</h4>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Initial Form</label>
                            <div class="badge">
                              <div style="margin: 20px;">
                                <div class="form-group">
                                  <label class="control-label label-modal">Customer Name</label><br>
                                  <label class="control-label label-gray"><f id="do_customer"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama Sales</label><br>
                                  <label class="control-label label-gray"><f id="do_sales"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama TL</label><br>
                                  <label class="control-label label-gray"><f id="do_leader"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">TL</label>
                                  <div class="row">
                                    <div class="col-md-1"><div class="square" style="margin-top: 5px;"></div></div>
                                    <label class="col-md-1 control-label label-gray">Dewa</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Motor</label><br>
                                  <label class="control-label label-gray"><f id="do_motor"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Warna</label><br>
                                  <label class="control-label label-gray"><f id="do_warna"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Fincoy</label><br>
                                  <label class="control-label label-gray"><f id="do_fincoy"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">DP</label><br>
                                  <label class="control-label label-gray"><f id="do_dp"></f></label>
                                </div>
                              </div>
                              </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">History</label>
                                  <div id="do_history_list"></div>
                                </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Comments</label>
                                  <div class="badge">
                                    <div style="margin: 20px;">
                                      <!-- start comment design -->
                                      <ul id="do_cm_list" class="media-list">
                                      </ul>
                                      <!-- end comment design -->
                                      <div class="form-group">
                                        <div class="row">
                                          <div class="col-md-4">
                                               <div class="form-group">
                                                  <div class="input-group">
                                                  <input id="do_comment" class="form-control" style="width: 450px;" />
                                                  <span class="input-group-btn">
                                                      <button id="myComment_do" class="btn btn-primary btn-block">Post
                                                      </button>
                                                  </span>
                                                  </div>
                                               </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="modal-dialog modal-right" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Current Phase</h4>
                            <h1 class="modal-title" style="color: #6093ca;">DO</h1>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Tanggal DO (Real)</label>
                                <div class="form-group">
                                  <div class='input-group date' id='date3' style="color: black;">
                                    <input type='text' class="form-control" id="do_history_date" placeholder="Choose Date"/>
                                    <span class="input-group-addon" >
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                              </div>
                          </div>
                          <div class="modal-footer">
                            <button id="myHistory_do" type="button" class="btn btn-primary">Submit</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                  <!-- end ModalDO -->
                  <!-- start ModalBatal-->
                    <div class="modal fade" id="ModalBatal" tabindex="-1" role="dialog" aria-labelledby="ModalListLabel">
                      <div class="row">
                      <div class="col-md-6 modal-left">
                      <div class="modal-dialog modal-left" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Card Details</h4>
                            <h1 class="modal-title" style="color: #6093ca;"><f id="batal_svno"></f> | <f id="batal_status"></f></h1>
                            <h4 class="modal-title" style="color: gray;">Created by Angga Pramana Putra on Feb 25, 2020 10:36 AM</h4>
                          </div>
                          <div class="modal-body">
                            <label class="control-label" style="font-size: 25px;">Initial Form</label>
                            <div class="badge">
                              <div style="margin: 20px;">
                                <div class="form-group">
                                  <label class="control-label label-modal">Customer Name</label><br>
                                  <label class="control-label label-gray"><f id="batal_customer"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama Sales</label><br>
                                  <label class="control-label label-gray"><f id="batal_sales"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Nama TL</label><br>
                                  <label class="control-label label-gray"><f id="batal_leader"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">TL</label>
                                  <div class="row">
                                    <div class="col-md-1"><div class="square" style="margin-top: 5px;"></div></div>
                                    <label class="col-md-1 control-label label-gray">Dewa</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Motor</label><br>
                                  <label class="control-label label-gray"><f id="batal_motor"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Warna</label><br>
                                  <label class="control-label label-gray"><f id="batal_warna"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">Fincoy</label><br>
                                  <label class="control-label label-gray"><f id="batal_fincoy"></f></label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label label-modal">DP</label><br>
                                  <label class="control-label label-gray"><f id="batal_dp"></f></label>
                                </div>
                              </div>
                              </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">History</label>
                                  <div id="batal_history_list"></div>
                                </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label" style="font-size: 25px;">Comments</label>
                                  <div class="badge">
                                    <div style="margin: 20px;">
                                      <!-- start comment design -->
                                      <ul id="batal_cm_list" class="media-list">
                                      </ul>
                                      <!-- end comment design -->
                                      <div class="form-group">
                                        <div class="row">
                                          <div class="col-md-4">
                                               <div class="form-group">
                                                  <div class="input-group">
                                                  <input id="batal_comment" class="form-control" style="width: 450px;" />
                                                  <span class="input-group-btn">
                                                      <button id="myComment_batal" class="btn btn-primary btn-block">Post
                                                      </button>
                                                  </span>
                                                  </div>
                                               </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="modal-dialog modal-right" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Current Phase</h4>
                            <h1 class="modal-title" style="color: #6093ca;">BATAL</h1>
                          </div>
                          <div class="modal-body">
                                  <label class="control-label" style="font-size: 25px;">Comment</label>
                                  <div class="form-group">
                                    <textarea placeholder="Leave your comment here" class="form-control" id="batal_history_description" rows="3"></textarea>
                                  </div>
                          </div>
                          <div class="modal-footer">
                            <button id="myHistory_batal" type="button" class="btn btn-primary">Submit</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                    </div>
                  <!-- end ModalBatal -->
                  
                  
                  <!-- start modal -->
                  <div class="modal fade" id="loadMe" tabindex="-1" role="dialog" aria-labelledby="loadMeLabel">
                    <div class="modal-dialog modal-sm" role="document">
                      <div class="modal-content">
                        <div class="modal-body text-center">
                          <div class="loader"></div>
                          <div clas="loader-txt">
                            <p>This process take view seconds</small></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  

      <script src="<?php echo base_url() ?>assets/js/dragula.min.js"></script>
      <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
      <script src="<?php echo base_url() ?>assets/bootstrap/js/moment.js"></script>
      <script type="text/javascript">
        var value = '';
        var sourceVal = '';
        var elVal = '';
        dragula([
            document.getElementById('card_pending'),
            document.getElementById('card_process'),
            document.getElementById('card_tolak'),
            document.getElementById('card_acc'),
           document.getElementById('card_do'),
           document.getElementById('card_batal')
        ], {
          accepts: function (el, target, source, sibling) {
            // console.log(el);
            // console.log(el.attributes[0].value);
            elVal = $(el).attr('data-id'); //get id
            if (source.id == 'card_pending') {
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return (target === document.getElementById('card_pending')||target === document.getElementById('card_process')||target === document.getElementById('card_batal'))
            }
            else if (source.id == 'card_process') {
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return (target === document.getElementById('card_process')||target === document.getElementById('card_tolak')||target === document.getElementById('card_acc')||target === document.getElementById('card_batal'))
            }
            else if (source.id == 'card_tolak') {
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return (target === document.getElementById('card_process')||target === document.getElementById('card_tolak')||target === document.getElementById('card_batal'))
            }
            else if (source.id == 'card_acc') {
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return (target === document.getElementById('card_acc')||target === document.getElementById('card_batal'))
            }
            else if (source.id == 'card_do') {
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return (target === document.getElementById('card_do'))
            }
            else if (source.id == 'card_batal') {
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return (target === document.getElementById('card_batal'))
            }
            else{
              el.classList.add('is-moving');
              value = target.id;
              sourceVal = source.id;
              return true;
            }

          }
        })

        // .on('drag', function(el) {
            
        //     // add 'is-moving' class to element being dragged
        //     el.classList.add('is-moving');
        // })
        .on('dragend', function(el) {
            
            // remove 'is-moving' class from element after dragging has stopped
            el.classList.remove('is-moving');
            
            // add the 'is-moved' class for 600ms then remove it
            window.setTimeout(function() {
                el.classList.add('is-moved');
                window.setTimeout(function() {
                    el.classList.remove('is-moved');
                }, 600);
            }, 100);
            console.log(value);

            function count_comment(svno){
              var count='';
              $.ajax({
                  type  : 'ajax',
                  url   : '<?php echo base_url()?>beranda/comment_count/'+svno,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                   // console.log(data);
                    return count =data.count;
                  }

              });

              return count;
            }

            function history_list(sv_no,status){
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_history/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  // console.log("data histor:  "+data);
                    var html_history_list = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        html_history_list += 
                         '<div class="badge" style="margin-bottom: 10px;">'+
                          '<div class="row" style="margin: 20px;">'+
                            '<div class="col-md-6" style="padding: unset;">'+
                              '<label class="control-label label-modal">'+data[i].status.toUpperCase()+'</label><br>'+
                              '<label class="control-label label-gray">'+moment(data[i].create_at).fromNow()+' in this phase</label><br>'+
                              '<label class="text-uppercase" style="color: #99badd;"><span class="glyphicon glyphicon-comment"></span>'+count_comment(data[i].sv_no)+'</label>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<label class="control-label" style="color: black;">'+moment(data[i].create_at).format("MMM D, YYYY")+'</f></label><br>'+
                              '<label class="control-label" style="color: #808080">'+moment(data[i].create_at).format("LT")+'</label>'+
                            '</div>'+
                          '</div>'+
                        '</div>';
                    }
                    console.log('history status:'+status);
                    if (status == 'acc') {
                      $('#acc_history_list').html(html_history_list);
                    }
                    else if (status == 'pending' || status == 'progress') {
                      $('#history_list').html(html_history_list);
                    }
                    else if (status == 'ditolak') {
                      $('#tolak_history_list').html(html_history_list);
                    }
                    else if (status == 'do') {
                      $('#do_history_list').html(html_history_list);
                    }
                    else {  
                      $('#batal_history_list').html(html_history_list);
                    }
                  }
              });
            }

            function daftar_comment(sv_no,status){
              // console.log('sv '+sv_no);
              // console.log('status '+status);
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_comment/'+sv_no+'/'+status,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  console.log(data);
                    var html_cm_list = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        if(data[i].foto != null){
                          var img = '<img class="media-object img-circle" src="<?php echo base_url()?>upload/'+data[i].foto+'" alt="profile">';
                      }else{
                        var img =  '<img class="media-object img-circle" src="<?php echo base_url()?>upload/avatar.png" alt="profile">';
                      }
                        html_cm_list += 
                        '<li class="media">'+
                          '<a class="pull-left" href="#">'+img+
                          '</a>'+
                          '<div class="media-body">'+
                          '<h5 class="media-heading text-uppercase reviews">'+data[i].nama+'</h5>'+
                            '<div class="well well-lg" style="padding: 8px;">'+
                                '<p class="media-comment" style="color: black;">'+
                                 data[i].text+
                                '</p>'+
                                '<h6 class="media-comment" style="color: gray; margin-bottom: auto;">'+data[i].tgl+' - on '+status+'</h6>'
                            '</div> '+             
                          '</div>'+
                        '</li>';
                    }
                    console.log(status);
                    if (status == 'acc') {
                      $('#acc_cm_list').html(html_cm_list);
                    }
                    else if (status == 'pending' || status == 'progress') {
                      $('#cm_list').html(html_cm_list);
                    }
                    else if (status == 'ditolak') {
                      $('#tolak_cm_list').html(html_cm_list);
                    }
                    else if (status == 'do') {
                      $('#do_cm_list').html(html_cm_list);
                    }
                    else {
                      $('#batal_cm_list').html(html_cm_list);
                    }
                  }
              });
            }

            function history_save(svno,status,text,userid){
              console.log("history save"+status)
              $.ajax({
                 type: 'post',
                 dataType : 'json',
                 url : '<?php echo base_url();?>'+'beranda/history_save/',
                 data: {svno:svno,status:status,text:text,userid:userid},
                 success: function(data){
                  //console.log(data);
                 }
              });
            }

            // function card_save(svno,status,userid){
            //   $.ajax({
            //      type: 'post',
            //      dataType : 'json',
            //      url : '<?php echo base_url();?>'+'beranda/card_save/',
            //      data: {svno:svno,status:status,userid:userid},
            //      success: function(data){
            //       //console.log(data);
            //      }
            //   });
            // }

            function showModal(value,elVal){
              if (value == 'card_tolak') {
                var status = '';
                $.ajax({
                    type : 'ajax',
                    url : '<?php echo base_url()?>beranda/data_svno/'+elVal,
                    async : false,
                    dataType : 'json',
                    success : function(data){
                    //console.log(data);
                      // document.getElementById("tolak_jml_komen").innerHTML = count_comment(elVal);
                      var i;
                      for(i=0; i<data.length; i++){
                        console.log(data[i].cust_name);
                        // document.getElementById("tolak_cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                        // document.getElementById("tolak_cm_date").innerHTML = data[i].sv_date;
                        document.getElementById("tolak_svno").innerHTML = data[i].sv_no;
                        document.getElementById("tolak_status").innerHTML = data[i].sv_result;
                        document.getElementById("tolak_customer").innerHTML = data[i].cust_name;
                        document.getElementById("tolak_sales").innerHTML = data[i].slm_name;
                        document.getElementById("tolak_leader").innerHTML = data[i].leader;
                        document.getElementById("tolak_motor").innerHTML = data[i].itm_name;
                        document.getElementById("tolak_warna").innerHTML = data[i].cl_name;
                        document.getElementById("tolak_fincoy").innerHTML = data[i].fc_code;
                        document.getElementById("tolak_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                        document.getElementById("tolak_comment").disabled = true;
                        document.getElementById("myComment_tolak").disabled = true;
                        status = data[i].sv_result.toLowerCase();
                      }
                    }
                });
                history_list(elVal,"ditolak");
                daftar_comment(elVal,"ditolak");

                $("#ModalTolak").modal();
              }
              else if (value == 'card_acc') {
                var status = '';
                $.ajax({
                    type : 'ajax',
                    url : '<?php echo base_url()?>beranda/data_svno/'+elVal,
                    async : false,
                    dataType : 'json',
                    success : function(data){
                    //console.log(data);
                      // document.getElementById("acc_jml_komen").innerHTML = count_comment(elVal);
                      var i;
                      for(i=0; i<data.length; i++){
                        console.log(data[i].cust_name);
                        // document.getElementById("acc_cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                        // document.getElementById("acc_cm_date").innerHTML = data[i].sv_date;
                        document.getElementById("acc_svno").innerHTML = data[i].sv_no;
                        document.getElementById("acc_status").innerHTML = data[i].sv_result;
                        document.getElementById("acc_customer").innerHTML = data[i].cust_name;
                        document.getElementById("acc_sales").innerHTML = data[i].slm_name;
                        document.getElementById("acc_leader").innerHTML = data[i].leader;
                        document.getElementById("acc_motor").innerHTML = data[i].itm_name;
                        document.getElementById("acc_warna").innerHTML = data[i].cl_name;
                        document.getElementById("acc_fincoy").innerHTML = data[i].fc_code;
                        document.getElementById("acc_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                        document.getElementById("acc_comment").disabled = true;
                        document.getElementById("myComment_acc").disabled = true;
                        status = data[i].sv_result.toLowerCase();
                      }
                    }
                });
                history_list(elVal,"acc");
                daftar_comment(elVal,"acc");
                $("#ModalAcc").modal();
              }
              else if (value == 'card_do') {
                var status = '';
                $.ajax({
                    type : 'ajax',
                    url : '<?php echo base_url()?>beranda/data_svno/'+elVal,
                    async : false,
                    dataType : 'json',
                    success : function(data){
                    //console.log(data);
                      // document.getElementById("do_jml_komen").innerHTML = count_comment(elVal);
                      var i;
                      for(i=0; i<data.length; i++){
                        console.log(data[i].cust_name);
                        // document.getElementById("do_cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                        // document.getElementById("do_cm_date").innerHTML = data[i].sv_date;
                        document.getElementById("do_svno").innerHTML = data[i].sv_no;
                        document.getElementById("do_status").innerHTML = data[i].sv_result;
                        document.getElementById("do_customer").innerHTML = data[i].cust_name;
                        document.getElementById("do_sales").innerHTML = data[i].slm_name;
                        document.getElementById("do_leader").innerHTML = data[i].leader;
                        document.getElementById("do_motor").innerHTML = data[i].itm_name;
                        document.getElementById("do_warna").innerHTML = data[i].cl_name;
                        document.getElementById("do_fincoy").innerHTML = data[i].fc_code;
                        document.getElementById("do_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                        document.getElementById("do_comment").disabled = true;
                        document.getElementById("myComment_do").disabled = true;
                        status = data[i].sv_result.toLowerCase();
                      }
                    }
                });
                history_list(elVal,"do");
                daftar_comment(elVal,"do");
                $("#ModalDo").modal();
              }
              else if (value == 'card_batal') {
                var status = '';
                $.ajax({
                    type : 'ajax',
                    url : '<?php echo base_url()?>beranda/data_svno/'+elVal,
                    async : false,
                    dataType : 'json',
                    success : function(data){
                    //console.log(data);
                      // document.getElementById("batal_jml_komen").innerHTML = count_comment(elVal);
                      var i;
                      for(i=0; i<data.length; i++){
                        console.log(data[i].cust_name);
                        // document.getElementById("batal_cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                        // document.getElementById("batal_cm_date").innerHTML = data[i].sv_date;
                        document.getElementById("batal_svno").innerHTML = data[i].sv_no;
                        document.getElementById("batal_status").innerHTML = data[i].sv_result;
                        document.getElementById("batal_customer").innerHTML = data[i].cust_name;
                        document.getElementById("batal_sales").innerHTML = data[i].slm_name;
                        document.getElementById("batal_leader").innerHTML = data[i].leader;
                        document.getElementById("batal_motor").innerHTML = data[i].itm_name;
                        document.getElementById("batal_warna").innerHTML = data[i].cl_name;
                        document.getElementById("batal_fincoy").innerHTML = data[i].fc_code;
                        document.getElementById("batal_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                        document.getElementById("batal_comment").disabled = true;
                        document.getElementById("myComment_batal").disabled = true;
                        status = data[i].sv_result.toLowerCase();
                      }
                    }
                });
                history_list(elVal,"batal");
                daftar_comment(elVal,"batal");
                $("#ModalBatal").modal();
              }
              else if (value == 'card_process') {
                console.log(elVal);
              }
            }

            // perpindahan card
            if (sourceVal == 'card_pending') {
              if (value == 'card_process' || value == 'card_pending' || value == 'card_batal') {
                //simpan_history(elVal,'PROGRESS',null);
                //console.log('svno'+elVal);
                var userid = "<?php echo $this->session->userdata('user_id')?>";
                history_save(elVal,'PROGRESS','',userid);
                showModal(value,elVal);
                
              }
              else {
                window.alert("Can't put to this section yet");
              }
            }
            else if (sourceVal == 'card_process') {
              if(value == 'card_process' || value == 'card_tolak' || value == 'card_batal' || value == 'card_acc' ){
                showModal(value,elVal);
                
              }
              else {
                window.alert("Can't put to this section yet");
              }
            }
            else if (sourceVal == 'card_tolak') {
              if(value == 'card_process' || value == 'card_tolak' || value == 'card_batal' || value == 'card_pending'){
                showModal(value,elVal);
                
              }
              else {
                window.alert("Can't put to this section yet");
              }
            }
            else if (sourceVal == 'card_acc') {
              if(value == 'card_acc' || value == 'card_batal'){
                showModal(value,elVal);
                
              }
              else {
                window.alert("Can't put to this section yet");
              }
            }
            else if (sourceVal == 'card_do') {
              if(value == 'card_do'){
                showModal(value,elVal);
                
              }
              else {
                window.alert("Can't put to this section yet");
              }
            }
            else if (sourceVal == 'card_batal') {
              if(value == 'card_batal'){
                showModal(value,elVal);
                
              }
              else {
                window.alert("Can't put to this section yet");
              }
            }

            

            });

      </script>

        <script type="text/javascript">
          $(document).ready(function() {
            
            $("#mySearch").on("click", function(e) {
                e.preventDefault();

                setTimeout(function() { setTime(); }, 1000);

              });

            function setTime() {
                $("#loadMe").modal({
                  backdrop: "static", //remove ability to close modal with click
                  keyboard: false, //remove option to close with keyboard
                  show: true //Display loader!
                });
                //alert("Delayed " + x1);
                x1 = 1000;
                
                setTimeout(function() {
                  load_data();
                 //hidden loading
                 $("#loadMe").modal("hide"); 

               }, x1);  
            }
            
            setTimeout(function() {
              var sgm = "<?php echo $this->session->userdata('user_sgm')?>";
              console.log('sgm_code:'+sgm)
              if(sgm == null || sgm == '' ){
                  team_list();
              }else{
                document.getElementById("selectTeam").style.display = "none";
              }
              // select team
              setTime(); }, 1000);

           $('#date1').datetimepicker({
               // dateFormat: 'dd-mm-yy',
               format:'YYYY-MM',
            });
            $('#date2').datetimepicker({
               // dateFormat: 'dd-mm-yy',
               format:'YYYY-MM-DD',
            });
            $('#date3').datetimepicker({
               // dateFormat: 'dd-mm-yy',
               format:'YYYY-MM-DD',
            });

            function load_data(){
              var date = document.getElementById("tgl").value;
              
              // cek akses user group team leader
              var sgm = "<?php echo $this->session->userdata('user_sgm')?>";
              if(sgm == null|| sgm == ''){
                var team = document.getElementById("team").value;
              }else{
                var team = sgm;
              }
              

              count_card(date,team);
              card(date,team);
            }

            function count_card(date,team){
              $.ajax({
                  type  : 'ajax',
                  url   : '<?php echo base_url()?>beranda/count/'+date+'/'+team,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                    //console.log(data);
                    document.getElementById("jml_pending_atas").innerHTML = data.pending;
                      document.getElementById("jml_pending_bawah").innerHTML = data.pending;
                      document.getElementById("jml_process_atas").innerHTML = data.process;
                      document.getElementById("jml_process_bawah").innerHTML = data.process;
                      document.getElementById("jml_batal_atas").innerHTML = data.batal;
                      document.getElementById("jml_batal_bawah").innerHTML = data.batal;
                      document.getElementById("jml_acc_atas").innerHTML = data.acc;
                      document.getElementById("jml_acc_bawah").innerHTML = data.acc;
                      document.getElementById("jml_do_atas").innerHTML = data.do;
                      document.getElementById("jml_do_bawah").innerHTML = data.do;
                      document.getElementById("jml_tolak_atas").innerHTML = data.tolak;
                      document.getElementById("jml_tolak_bawah").innerHTML = data.tolak;
                  }

              });
            }

            function team_list(){
              $.ajax({
                    type : 'ajax',
                    url : '<?php echo base_url()?>beranda/get_team/',
                    async : false,
                    dataType : 'json',
                    success : function(data){
                    //console.log(data);
                      var html = '<option value="ALL">ALL</option>';
                      var i;
                      for(i=0; i<data.length; i++){
                          html += 
                           '<option value="'+data[i].sgm_code+'">'+data[i].sgm_account+'</option>';
                      }
                      $('#team').html(html);
                    }
                });
              
            }

            function count_comment(svno){
              var count='';
              $.ajax({
                  type  : 'ajax',
                  url   : '<?php echo base_url()?>beranda/comment_count/'+svno,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                   // console.log(data);
                    return count =data.count;
                  }

              });

              return count;
            }

            function card(date,team){
                $.ajax({
                    type  : 'ajax',
                    url   : '<?php echo base_url()?>beranda/data_card/'+date+'/'+team,
                    async : false,
                    dataType : 'json',
                    success : function(data){
                      //console.log(data.pending);
                      // count cart
                     /* document.getElementById("jml_pending_atas").innerHTML = data.count.pending;
                      document.getElementById("jml_pending_bawah").innerHTML = data.count.pending;
                      document.getElementById("jml_process_atas").innerHTML = data.count.process;
                      document.getElementById("jml_process_bawah").innerHTML = data.count.process;
                      document.getElementById("jml_batal_atas").innerHTML = data.count.batal;
                      document.getElementById("jml_batal_bawah").innerHTML = data.count.batal;
                      document.getElementById("jml_acc_atas").innerHTML = data.count.acc;
                      document.getElementById("jml_acc_bawah").innerHTML = data.count.acc;
                      document.getElementById("jml_do_atas").innerHTML = data.count.do;
                      document.getElementById("jml_do_bawah").innerHTML = data.count.do;
                      document.getElementById("jml_tolak_atas").innerHTML = data.count.tolak;
                      document.getElementById("jml_tolak_bawah").innerHTML = data.count.tolak;
                      // end count cart*/

                      // card start
                        var html_pending = '';
                        var i;
                        var pending = data.pending;
                        for(i=0; i<pending.length; i++){
                            html_pending += 
                            '<button data-id="'+pending[i].sv_no+'" class="btn drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" >'+
                            '<div class="col-md-6" style="padding-top: 6px;">'+
                              '<div class="square"></div>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<div class="label label-warning">LATE</div>'+
                            '</div><br>'+
                            '<div class="list-wrap">'+
                              '<div style="font-weight: bold;">'+pending[i].cust_name+'</div>'+
                              '<div>'+pending[i].slm_name+'</div>'+
                              '<p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span><?php echo $this->Comment_model->get_count('<script>pending[i].sv_no</>')?></p>'+
                            '</div>'+
                            '</button>';
                        }
                        $('#card_pending').html(html_pending);

                        var html_progress = '';
                        var progress = data.progress;
                        for(i=0; i<progress.length; i++){
                            html_progress += 
                            '<button data-id="'+progress[i].sv_no+'" class="btn drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" >'+
                            '<div class="col-md-6" style="padding-top: 6px;">'+
                              '<div class="square"></div>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<div class="label label-warning">LATE</div>'+
                            '</div><br>'+
                            '<div class="list-wrap">'+
                              '<div style="font-weight: bold;">'+progress[i].cust_name+'</div>'+
                              '<div>'+progress[i].slm_name+'</div>'+
                              '<p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span><?php echo $this->Comment_model->get_count('<script>progress[i].sv_no</>')?></p>'+
                            '</div>'+
                            '</button>';
                        }
                        $('#card_process').html(html_progress);

                        var html_tolak = '';
                        var tolak = data.tolak;
                        for(i=0; i<tolak.length; i++){
                            html_tolak += 
                            '<button data-id="'+tolak[i].sv_no+'" class="btn drag-item list-group-item" data-toggle="modal" data-target="#ModalTolak" data-whatever="li" >'+
                            '<div class="col-md-6" style="padding-top: 6px;">'+
                              '<div class="square"></div>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<div class="label label-warning">LATE</div>'+
                            '</div><br>'+
                            '<div class="list-wrap">'+
                              '<div style="font-weight: bold;">'+tolak[i].cust_name+'</div>'+
                              '<div>'+tolak[i].slm_name+'</div>'+
                              '<p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span><?php echo $this->Comment_model->get_count('<script>tolak[i].sv_no</>')?></p>'+
                            '</div>'+
                            '</button>';
                        }
                        $('#card_tolak').html(html_tolak);

                        var html_acc = '';
                        var acc = data.acc;
                        for(i=0; i<acc.length; i++){
                            html_acc += 
                            '<button data-id="'+acc[i].sv_no+'" class="btn drag-item list-group-item" data-toggle="modal" data-target="#ModalAcc" data-whatever="li" >'+
                            '<div class="col-md-6" style="padding-top: 6px;">'+
                              '<div class="square"></div>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<div class="label label-warning">LATE</div>'+
                            '</div><br>'+
                            '<div class="list-wrap">'+
                              '<div style="font-weight: bold;">'+acc[i].cust_name+'</div>'+
                              '<div>'+acc[i].slm_name+'</div>'+
                              '<p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span><?php echo $this->Comment_model->get_count('<script>acc[i].sv_no</>')?></p>'+
                            '</div>'+
                            '</button>';
                        }
                        $('#card_acc').html(html_acc);

                        var html_do = '';
                        var sudah = data.do;
                        for(i=0; i<sudah.length; i++){
                            html_do += 
                            '<button data-id="'+sudah[i].sv_no+'" class="btn drag-item list-group-item" data-toggle="modal" data-target="#ModalDo" data-whatever="li" >'+
                            '<div class="col-md-6" style="padding-top: 6px;">'+
                              '<div class="square"></div>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<div class="label label-warning">LATE</div>'+
                            '</div><br>'+
                            '<div class="list-wrap">'+
                              '<div style="font-weight: bold;">'+sudah[i].cust_name+'</div>'+
                              '<div>'+sudah[i].slm_name+'</div>'+
                              '<p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span><?php echo $this->Comment_model->get_count('<script>sudah[i].sv_no</>')?></p>'+
                            '</div>'+
                            '</button>';
                        }
                        $('#card_do').html(html_do);

                        var html_batal = '';
                        var batal = data.batal;
                        for(i=0; i<batal.length; i++){
                            html_batal += 
                            '<button data-id="'+batal[i].sv_no+'" class="btn drag-item list-group-item" data-toggle="modal" data-target="#ModalBatal" data-whatever="li" >'+
                            '<div class="col-md-6" style="padding-top: 6px;">'+
                              '<div class="square"></div>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<div class="label label-warning">LATE</div>'+
                            '</div><br>'+
                            '<div class="list-wrap">'+
                              '<div style="font-weight: bold;">'+batal[i].cust_name+'</div>'+
                              '<div>'+batal[i].slm_name+'</div>'+
                              '<p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span><?php echo $this->Comment_model->get_count('<script>batal[i].sv_no</>')?></p>'+
                            '</div>'+
                            '</button>';
                        }
                        $('#card_batal').html(html_batal);
                        //Card end
                      
                    }
                });
            }

            $('#ModalList').on('show.bs.modal', function (e) {
              var sv_no = $(e.relatedTarget).data('id');
              /* fungsi AJAX untuk melakukan fetch data */
              var status = '';
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_svno/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  //console.log(data);
                    // document.getElementById("jml_komen").innerHTML = count_comment(sv_no);
                    var i;
                    for(i=0; i<data.length; i++){
                      console.log(data[i].cust_name);
                      // document.getElementById("cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                      // document.getElementById("cm_date").innerHTML = data[i].sv_date;
                      document.getElementById("svno").innerHTML = data[i].sv_no;
                      document.getElementById("status").innerHTML = data[i].sv_result;
                      document.getElementById("customer").innerHTML = data[i].cust_name;
                      document.getElementById("sales").innerHTML = data[i].slm_name;
                      document.getElementById("leader").innerHTML = data[i].leader;
                      document.getElementById("motor").innerHTML = data[i].itm_name;
                      document.getElementById("warna").innerHTML = data[i].cl_name;
                      document.getElementById("fincoy").innerHTML = data[i].fc_code;
                      document.getElementById("dp").innerHTML = Math.round(data[i].sv_dpsetor);
                      status = data[i].sv_result.toLowerCase();
                    }
                  }
              });

              history_list(sv_no,status);
              comment_list(sv_no,status);
              

           });

          $("#myComment_list").on("click", function(e) {
                e.preventDefault();
                var svno = document.getElementById("svno").innerHTML;
                var status = document.getElementById("status").innerHTML.toLowerCase();
                var comment = document.getElementById("comment").value;
                var userid = "<?php echo $this->session->userdata('user_id')?>";
                console.log(svno+'/'+status+'/'+comment+'/'+userid);

                comment_save(svno,status,comment,userid);
                comment_list(svno,status);
              });

            

          $('#ModalTolak').on('show.bs.modal', function (e) {
              var sv_no = $(e.relatedTarget).data('id');
              /* fungsi AJAX untuk melakukan fetch data */
              var status = '';
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_svno/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  //console.log(data);
                    // document.getElementById("tolak_jml_komen").innerHTML = count_comment(sv_no);
                    var i;
                    for(i=0; i<data.length; i++){
                      console.log(data[i].cust_name);
                      // document.getElementById("tolak_cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                      // document.getElementById("tolak_cm_date").innerHTML = data[i].sv_date;
                      document.getElementById("tolak_svno").innerHTML = data[i].sv_no;
                      document.getElementById("tolak_status").innerHTML = data[i].sv_result;
                      document.getElementById("tolak_customer").innerHTML = data[i].cust_name;
                      document.getElementById("tolak_sales").innerHTML = data[i].slm_name;
                      document.getElementById("tolak_leader").innerHTML = data[i].leader;
                      document.getElementById("tolak_motor").innerHTML = data[i].itm_name;
                      document.getElementById("tolak_warna").innerHTML = data[i].cl_name;
                      document.getElementById("tolak_fincoy").innerHTML = data[i].fc_code;
                      document.getElementById("tolak_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                      document.getElementById("tolak_comment").disabled = false;
                      document.getElementById("myComment_tolak").disabled = false;
                      status = data[i].sv_result.toLowerCase();
                    }
                  }
              });
              history_list(sv_no,status);
              comment_list(sv_no,status);

           });

          $("#myComment_tolak").on("click", function(e) {
                e.preventDefault();
                var svno = document.getElementById("tolak_svno").innerHTML;
                var status = document.getElementById("tolak_status").innerHTML.toLowerCase();
                var comment = document.getElementById("tolak_comment").value;
                var userid = "<?php echo $this->session->userdata('user_id')?>";
                console.log(svno+'/'+status+'/'+comment+'/'+userid);

                comment_save(svno,status,comment,userid);
                comment_list(svno,status);
              });

          $("#myHistory_tolak").on("click", function(e) {
            e.preventDefault();
            var svno = document.getElementById("tolak_svno").innerHTML;
            var status = 'DITOLAK';
            var date = moment().format("YYYY-MM-DD");
            var radio = $("input[name='radioStep']:checked").val();
            var deskripsi = document.getElementById("tolak_history_description").value;
            var text = date+','+deskripsi+','+radio;

            var userid = "<?php echo $this->session->userdata('user_id')?>";
            history_save(svno,status,text,userid);
            history_list(svno,status);
            $('#ModalTolak').modal('toggle'); // hide modal after click submit
          });

          $('#ModalAcc').on('show.bs.modal', function (e) {
              var sv_no = $(e.relatedTarget).data('id');
              /* fungsi AJAX untuk melakukan fetch data */
              var status = '';
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_svno/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                    var i;
                    for(i=0; i<data.length; i++){
                      //console.log(data[i].cust_name);
                      document.getElementById("acc_svno").innerHTML = data[i].sv_no;
                      document.getElementById("acc_status").innerHTML = data[i].sv_result;
                      document.getElementById("acc_customer").innerHTML = data[i].cust_name;
                      document.getElementById("acc_sales").innerHTML = data[i].slm_name;
                      document.getElementById("acc_leader").innerHTML = data[i].leader;
                      document.getElementById("acc_motor").innerHTML = data[i].itm_name;
                      document.getElementById("acc_warna").innerHTML = data[i].cl_name;
                      document.getElementById("acc_fincoy").innerHTML = data[i].fc_code;
                      document.getElementById("acc_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                      document.getElementById("acc_comment").disabled = false;
                      document.getElementById("myComment_acc").disabled = false;
                      status = data[i].sv_result.toLowerCase();
                    }
                  }
              });
              history_list(sv_no,status);
              comment_list(sv_no,status);
           });

          $("#myComment_acc").on("click", function(e) {
                e.preventDefault();
                var svno = document.getElementById("acc_svno").innerHTML;
                var status = document.getElementById("acc_status").innerHTML.toLowerCase();
                var comment = document.getElementById("acc_comment").value;
                var userid = "<?php echo $this->session->userdata('user_id')?>";
                console.log(svno+'/'+status+'/'+comment+'/'+userid);

                comment_save(svno,status,comment,userid);
                comment_list(svno,status);
              });

          $("#myHistory_acc").on("click", function(e) {
            e.preventDefault();
            var svno = document.getElementById("acc_svno").innerHTML;
            var status = 'ACC';
            var date = document.getElementById("history_date").value;
            var deskripsi = document.getElementById("history_description").value;
            var text = date+','+deskripsi;
            var userid = "<?php echo $this->session->userdata('user_id')?>";
            history_save(svno,status,text,userid);
            history_list(svno,status);
            $('#ModalAcc').modal('toggle'); // hide modal after click submit
          });

          $('#ModalDo').on('show.bs.modal', function (e) {
              var sv_no = $(e.relatedTarget).data('id');
              /* fungsi AJAX untuk melakukan fetch data */
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_svno/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  //console.log(data);
                    // document.getElementById("do_jml_komen").innerHTML = count_comment(sv_no);
                    var i;
                    for(i=0; i<data.length; i++){
                      console.log(data[i].cust_name);
                      // document.getElementById("do_cm_tgl").innerHTML = moment(data[i].sv_date).fromNow();
                      // document.getElementById("do_cm_date").innerHTML = data[i].sv_date;
                      document.getElementById("do_svno").innerHTML = data[i].sv_no;
                      document.getElementById("do_status").innerHTML = data[i].sv_result;
                      document.getElementById("do_customer").innerHTML = data[i].cust_name;
                      document.getElementById("do_sales").innerHTML = data[i].slm_name;
                      document.getElementById("do_leader").innerHTML = data[i].leader;
                      document.getElementById("do_motor").innerHTML = data[i].itm_name;
                      document.getElementById("do_warna").innerHTML = data[i].cl_name;
                      document.getElementById("do_fincoy").innerHTML = data[i].fc_code;
                      document.getElementById("do_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                      document.getElementById("do_comment").disabled = false;
                      document.getElementById("myComment_do").disabled = false;
                      status = data[i].sv_result.toLowerCase();
                    }
                  }
              });
              history_list(sv_no,status);
              comment_list(sv_no,'do');
           });
          $("#myComment_do").on("click", function(e) {
                e.preventDefault();
                var svno = document.getElementById("do_svno").innerHTML;
                var status = document.getElementById("do_status").innerHTML.toLowerCase();
                var comment = document.getElementById("do_comment").value;
                var userid = "<?php echo $this->session->userdata('user_id')?>";
                //console.log(svno+'/'+status+'/'+comment+'/'+userid);

                comment_save(svno,status,comment,userid);
                comment_list(svno,'do');
              });
          $("#myHistory_do").on("click", function(e) {
            e.preventDefault();
            var svno = document.getElementById("do_svno").innerHTML;
            var status = 'DO';
            var date = document.getElementById("do_history_date").value;
            var deskripsi = "";
            var text = date+','+deskripsi;
            var userid = "<?php echo $this->session->userdata('user_id')?>";
            history_save(svno,status,text,userid);
            history_list(svno,status);
            $('#ModalDo').modal('toggle'); // hide modal after click submit
          });

          $('#ModalBatal').on('show.bs.modal', function (e) {
              var sv_no = $(e.relatedTarget).data('id');
              /* fungsi AJAX untuk melakukan fetch data */
              var status = '';
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_svno/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  //console.log(data);
                    // document.getElementById("batal_jml_komen").innerHTML = count_comment(sv_no);
                    var i;
                    for(i=0; i<data.length; i++){
                      console.log(data[i].cust_name);
                      document.getElementById("batal_svno").innerHTML = data[i].sv_no;
                      document.getElementById("batal_status").innerHTML = data[i].sv_result;
                      document.getElementById("batal_customer").innerHTML = data[i].cust_name;
                      document.getElementById("batal_sales").innerHTML = data[i].slm_name;
                      document.getElementById("batal_leader").innerHTML = data[i].leader;
                      document.getElementById("batal_motor").innerHTML = data[i].itm_name;
                      document.getElementById("batal_warna").innerHTML = data[i].cl_name;
                      document.getElementById("batal_fincoy").innerHTML = data[i].fc_code;
                      document.getElementById("batal_dp").innerHTML = Math.round(data[i].sv_dpsetor);
                      document.getElementById("batal_comment").disabled = false;
                      document.getElementById("myComment_batal").disabled = false;
                      status = data[i].sv_result.toLowerCase();
                    }
                  }
              });
              history_list(sv_no,status);
              comment_list(sv_no,status);
           });
          $("#myComment_batal").on("click", function(e) {
                e.preventDefault();
                var svno = document.getElementById("batal_svno").innerHTML;
                var status = document.getElementById("batal_status").innerHTML.toLowerCase();
                var comment = document.getElementById("batal_comment").value;
                var userid = "<?php echo $this->session->userdata('user_id')?>";
                //console.log(svno+'/'+status+'/'+comment+'/'+userid);
                comment_save(svno,status,comment,userid);
                comment_list(svno,status);
              });
          $("#myHistory_batal").on("click", function(e) {
            e.preventDefault();

            var svno = document.getElementById("batal_svno").innerHTML;
            var status = 'CANCEL';
            var date = moment().format("YYYY-MM-DD");
            var deskripsi = document.getElementById("batal_history_description").value;
            var text = date+','+deskripsi;
            var userid = "<?php echo $this->session->userdata('user_id')?>";
            history_save(svno,status,text,userid);
            history_list(svno,status);
            $('#ModalBatal').modal('toggle'); // hide modal after click submit
          });

              function comment_save(svno,status,text,userid){
                $.ajax({
                   type: 'post',
                   dataType : 'json',
                   url : '<?php echo base_url();?>'+'beranda/comment_save',
                   data: {svno:svno,status:status,text:text,userid:userid},
                   success: function(data){
                   // console.log(data);
                   }
                });
              }

              function comment_list(sv_no,status){
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_comment/'+sv_no+'/'+status,
                  async : false,
                  dataType : 'json',
                  success : function(data){

                  //console.log(data);
                    var html_cm_list = '';
                    var i;
                    for(i=0; i<data.length; i++){
                      if(data[i].foto != null){
                          var img = '<img class="media-object img-circle" src="<?php echo base_url()?>upload/'+data[i].foto+'" alt="profile">';
                      }else{
                        var img =  '<img class="media-object img-circle" src="<?php echo base_url()?>upload/avatar.png" alt="profile">';
                      }
                        html_cm_list += 
                        '<li class="media">'+
                          '<a class="pull-left" href="#">'+img+
                          '</a>'+
                          '<div class="media-body">'+
                          '<h5 class="media-heading text-uppercase reviews">'+data[i].nama+'</h5>'+
                            '<div class="well well-lg" style="padding: 8px;">'+
                                '<p class="media-comment" style="color: black;">'+
                                 data[i].text+
                                '</p>'+
                                '<h6 class="media-comment" style="color: gray; margin-bottom: auto;">'+moment(data[i].tgl).format("MMM D, YYYY LT")+' - on '+status.toUpperCase()+'</h6>'
                            '</div> '+             
                          '</div>'+
                        '</li>';
                    }
                    // console.log(status);
                    if (status == 'acc') {
                      $('#acc_cm_list').html(html_cm_list);
                    }
                    else if (status == 'pending' || status == 'progress') {
                      $('#cm_list').html(html_cm_list);
                    }
                    else if (status == 'ditolak') {
                      $('#tolak_cm_list').html(html_cm_list);
                    }
                    else if (status == 'do') {
                      $('#do_cm_list').html(html_cm_list);
                    }
                    else {
                      $('#batal_cm_list').html(html_cm_list);
                    }
                  }
              });
            }

            function count_history(svno,status){
              var count='';
              $.ajax({
                  type  : 'ajax',
                  url   : '<?php echo base_url()?>beranda/history_count/'+svno+'/'+status,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                   // console.log(data);
                    return count =data.count;
                  }

              });
              return count;
            }

            function history_update(id,text){
                $.ajax({
                   type: 'post',
                   dataType : 'json',
                   url : '<?php echo base_url();?>'+'beranda/history_update',
                   data: {id:id,text:text},
                   success: function(data){
                    console.log(data);
                   }
                });
              }

              function history_save(svno,status,text,userid){
                console.log("history save= "+status);
                $.ajax({
                   type: 'post',
                   dataType : 'json',
                   url : '<?php echo base_url();?>'+'beranda/history_save/',
                   data: {svno:svno,status:status,text:text,userid:userid},
                   success: function(data){
                    console.log(data);
                   }
                });
              }

              function history_list(sv_no,status){
                status = status.toLowerCase();
              $.ajax({
                  type : 'ajax',
                  url : '<?php echo base_url()?>beranda/data_history/'+sv_no,
                  async : false,
                  dataType : 'json',
                  success : function(data){
                  //console.log(data);
                    var html_history_list = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        html_history_list += 
                         '<div class="badge" style="margin-bottom: 10px;">'+
                          '<div class="row" style="margin: 20px;">'+
                            '<div class="col-md-6" style="padding: unset;">'+
                              '<label class="control-label label-modal">'+data[i].status.toUpperCase()+'</label><br>'+
                              '<label class="control-label label-gray">'+moment(data[i].create_at).fromNow()+' in this phase</label><br>'+
                              '<label class="text-uppercase" style="color: #99badd;"><span class="glyphicon glyphicon-comment"></span>'+count_comment(data[i].sv_no)+'</label>'+
                            '</div>'+
                            '<div class="col-md-6" style="text-align: right;">'+
                              '<label class="control-label" style="color: black;">'+moment(data[i].create_at).format("MMM D, YYYY")+'</f></label><br>'+
                              '<label class="control-label" style="color: #808080">'+moment(data[i].create_at).format("LT")+'</label>'+
                            '</div>'+
                          '</div>'+
                        '</div>';
                    }
                    // console.log('history status:'+status);
                    if (status == 'acc') {
                      $('#acc_history_list').html(html_history_list);
                    }
                    else if (status == 'pending' || status == 'progress') {
                      $('#history_list').html(html_history_list);
                    }
                    else if (status == 'ditolak') {
                      $('#tolak_history_list').html(html_history_list);
                    }
                    else if (status == 'do') {
                      $('#do_history_list').html(html_history_list);
                    }
                    else {
                      $('#batal_history_list').html(html_history_list);
                    }
                  }
              });
            }
            
            
           });
        </script>
       
      </section>