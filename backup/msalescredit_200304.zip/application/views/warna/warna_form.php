<!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                
                  <h3 class='box-title'>WARNA</h3>
                      <div class='box box-primary'>
        <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
	    <tr><td>Kode Tl <?php echo form_error('kd_tl') ?></td>
            <td><input type="text" class="form-control" name="kd_tl" id="kd_tl" placeholder="Kd Tl" value="<?php echo $kd_tl; ?>" />
        </td>
	    <tr><td>Kode Warna<?php echo form_error('kode') ?></td>
            <td><div class="input-group my-colorpicker2">
                  <input type="text" class="form-control" name="kode" id="kode" placeholder="Kode" value="<?php echo $kode; ?>">

                  <div class="input-group-addon">
                    <i></i>
                  </div>
                </div>


        </td>
	    <tr><td>Name <?php echo form_error('name') ?></td>
            <td><input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo $name; ?>" />
        </td>
	    <tr><td>User <?php echo form_error('user_id') ?></td>
            <td><input type="text" class="form-control" name="user_id" id="user_id" placeholder="User Id" value="<?php echo $user_id; ?>" />
        </td>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('warna') ?>" class="btn btn-default">Cancel</a></td></tr>
	
    </table></form>
    </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
        <script  src="<?php echo base_url() ?>template/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $(".my-colorpicker1").colorpicker();
      //color picker with addon
      $(".my-colorpicker2").colorpicker();
    });
</script>