<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Beranda extends CI_Controller
{
    
        
    function __construct()
    {
        parent::__construct();
        $this->load->model('Survey_model');
        if($this->session->userdata('user_logedin') != 'TRUE'){ redirect('login', 'refresh');}
    }


    public function range($date=null)
    {
      if($date==null){
        $tgl = date('Y-m-d');
      }else{
        $tgl = $date;
      }
      
      $pending = $this->Survey_model->get_pending($tgl);
      $process = $this->Survey_model->get_status($tgl,'PROCESS');
      $do = $this->Survey_model->get_do($tgl);
      $acc = $this->Survey_model->get_acc($tgl);
      $tolak = $this->Survey_model->get_status($tgl,'DITOLAK');
      $batal = $this->Survey_model->get_status($tgl,'CANCEL');

      $count_acc = $this->Survey_model->get_count_acc($tgl);
      $count_tolak = $this->Survey_model->get_count_status($tgl,'DITOLAK');
      $count_batal = $this->Survey_model->get_count_status($tgl,'CANCEL');
      $count_pending = $this->Survey_model->get_count_pending($tgl);
      $count_process = $this->Survey_model->get_count_status($tgl,'PROCESS');
      $count_do = $this->Survey_model->get_count_do($tgl);
        $data = array(
          'data_pending' => $pending,
          'data_process' => $process,
          'data_acc' => $acc,
          'data_do' => $do,
          'data_tolak' => $tolak,
          'data_batal' => $batal,
          'jml_acc'=>$count_acc,
          'jml_batal'=>$count_batal,
          'jml_tolak'=>$count_tolak,
          'jml_pending'=>$count_pending,
          'jml_process'=>$count_process,
          'jml_do'=>$count_do,
          'tgl' => $tgl
        );

        $this->template->load('template','beranda', $data);

    }
}