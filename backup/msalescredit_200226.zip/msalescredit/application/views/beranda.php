
      <!-- Main content -->
      <section class="content">
        <!-- penampilan total record -->
        <div class="row">
          <div class='col-lg-12'>
        	<div class="callout callout-success">
                <h4>Selamat Datang di M-Sales Credit</h4>
              </div>
          </div>
        </div>
        <div class="row">
        <div class='col-sm-2'>
            <div class="form-group">
                <div class='input-group date' id='date1'>
                    <input type='text' id='tgl' value="<?php echo $tgl ?> " class="form-control" placeholder="Start Date"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
        </div>
        <!--<div class='col-sm-2'>
            <div class="form-group">
                <div class='input-group date' id='date2'>
                    <input type='text' class="form-control" placeholder="End Date"/>
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
        </div>-->
        <div class="col-sm-2">
            <button onclick="mySearch()" class="btn btn-info"><i class="fa fa-search"></i></button>
        </div>
         <script>
            function mySearch() {
              var date1 = document.getElementById("tgl").value;  
              var base_url="<?php echo base_url(); ?>";
            
              window.location.href = base_url+'beranda/range/'+date1;
            }
            </script>
      </div>
        <!-- <div class="drag-container"> -->
          
            <ul class="drag-list">
                <li class="drag-column drag-column-start">
                    <span class="drag-column-header">
                        <h2 style="color: white;">Belum Survey</h2>
                        <button class="btn btn-default" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" type="submit" style="margin-left: auto;"><i class="fa fa-plus"></i></button>
                        <svg class="drag-header-more" data-target="options1" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </span>
                    <span class="drag-column-header">
                      <span class="label label-warning" style="margin-right: 7px"><?php echo $jml_pending?></span>
                      <h6 style="margin-right: auto; color: white;"><?php echo $jml_pending?> card</h6>
                    </span>
                    
                    <div class="drag-options" id="options1"></div>
                    
                    <ul class="drag-inner-list" id="1">
                        <?php
                        $start = 0;
                        foreach ($data_pending as $row)
                        { ?>
                          <button class="btn btn-default drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" type="submit">
                            <div class="square"></div>
                            <div class="label label-warning" style="margin-right: 7px">LATE</div>
                            <div class="font-weight-bold">Dewa</div>
                            <div>Jamal</div>
                            <p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span> 2</p>
                          </button>
                        <?php }?>
                    </ul>
                    <h6 style="text-align: center; color: gray;">Customers booking</h6>
                </li>
                <li class="drag-column drag-column-in-progress">
                    <span class="drag-column-header">
                        <h2 style="color: white;">Survey</h2>
                        <svg class="drag-header-more" data-target="options2" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </span>
                    <span class="drag-column-header">
                      <span class="label label-warning" style="margin-right: 7px"><?php echo $jml_process?></span>
                      <h6 style="margin-right: auto; color: white;"><?php echo $jml_process?> card</h6>
                    </span>
                    <div class="drag-options" id="options2"></div>
                    <ul class="drag-inner-list" id="2">
                      <?php
                        $start = 0;
                        foreach ($data_process as $row)
                        { ?>
                        <button class="btn btn-default drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" type="submit">
                          <div class="square"></div>
                          <div class="label label-warning" style="margin-right: 7px">LATE</div>
                          <div class="font-weight-bold"><?php echo $row->cust_name ?></div>
                          <div><?php echo $row->slm_name ?></div>
                          <p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span> 2</p>
                        </button>
                      <?php } ?>
                    </ul>
                    <h6 style="text-align: center; color: gray;">Hasil survey belum keluar</h6>
                </li>
                <li class="drag-column drag-column-danger">
                    <span class="drag-column-header">
                        <h2 style="color: white;">Ditolak</h2>
                        <svg data-target="options3" class="drag-header-more" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </span>
                    <span class="drag-column-header">
                      <span class="label label-warning" style="margin-right: 7px"><?php echo $jml_tolak?></span>
                      <h6 style="margin-right: auto; color: white;"><?php echo $jml_tolak?> card</h6>
                    </span>
                    <div class="drag-options" id="options3"></div>
                    <ul class="drag-inner-list" id="3">
                      <?php
                        $start = 0;
                        foreach ($data_tolak as $row)
                        { ?>
                        <button class="btn btn-default drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" type="submit">
                          <div class="square"></div>
                          <div class="label label-warning" style="margin-right: 7px">LATE</div>
                          <div class="font-weight-bold"><?php echo $row->cust_name ?></div>
                          <div><?php echo $row->slm_name ?></div>
                          <p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span> 2</p>
                        </button>
                      <?php } ?>
                    </ul>
                    <h6 style="text-align: center; color: gray;">Survey yang ditolak</h6>
                </li>
                <li class="drag-column drag-column-approved">
                    <span class="drag-column-header">
                        <h2 style="color: white;">ACC</h2>
                        <svg data-target="options4" class="drag-header-more" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </span>
                    <span class="drag-column-header">
                      <span class="label label-warning" style="margin-right: 7px"><?php echo $jml_acc?></span>
                      <h6 style="margin-right: auto; color: white;"><?php echo $jml_acc?> card</h6>
                    </span>
                    <div class="drag-options" id="options4"></div>
                    <ul class="drag-inner-list" id="4">
                      <?php
                        $start = 0;
                        foreach ($data_acc as $row)
                        { ?>
                        <button class="btn btn-default drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" type="submit">
                          <div class="square"></div>
                          <div class="label label-warning" style="margin-right: 7px">LATE</div>
                          <div class="font-weight-bold"><?php echo $row->cust_name ?></div>
                          <div><?php echo $row->slm_name ?></div>
                          <p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span> 2</p>
                        </button>
                      <?php } ?>
                    </ul>
                    <h6 style="text-align: center; color: gray;">Sudah di ACC belum DO</h6>
                </li>
                <li class="drag-column drag-column-on-hold">
                    <span class="drag-column-header">
                        <h2 style="color: white;">Do</h2>
                        <svg data-target="options5" class="drag-header-more" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </span>
                    <span class="drag-column-header">
                      <span class="label label-warning" style="margin-right: 7px"><?php echo $jml_do?></span>
                      <h6 style="margin-right: auto; color: white;"><?php echo $jml_do?> card</h6>
                    </span>
                    <div class="drag-options" id="options5"></div>
                    <ul class="drag-inner-list" id="5">
                      <?php
                        $start = 0;
                        foreach ($data_do as $row)
                        { ?>
                        <button class="btn btn-default drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" type="submit">
                          <div class="square"></div>
                          <div class="label label-warning" style="margin-right: 7px">LATE</div>
                          <div class="font-weight-bold"><?php echo $row->cust_name ?></div>
                          <div><?php echo $row->slm_name ?></div>
                          <p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span> 2</p>
                        </button>
                      <?php } ?>
                    </ul>
                    <h6 style="text-align: center; color: gray;">Congratulations!</h6>
                </li>
                <li class="drag-column drag-column-cancel">
                    <span class="drag-column-header">
                        <h2 style="color: white;">Batal</h2>
                        <svg data-target="options6" class="drag-header-more" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </span>
                    <span class="drag-column-header">
                      <span class="label label-warning" style="margin-right: 7px"><?php echo $jml_batal?></span>
                      <h6 style="margin-right: auto; color: white;"><?php echo $jml_batal?> card</h6>
                    </span>
                    <div class="drag-options" id="options6"></div>
                    <ul class="drag-inner-list" id="6">
                      <?php
                        $start = 0;
                        foreach ($data_batal as $row)
                        { ?>
                        <button class="btn btn-default drag-item list-group-item" data-toggle="modal" data-target="#ModalList" data-whatever="li" type="submit">
                          <div class="square"></div>
                          <div class="label label-warning" style="margin-right: 7px">LATE</div>
                          <div class="font-weight-bold"><?php echo $row->cust_name ?></div>
                          <div><?php echo $row->slm_name ?></div>
                          <p style="color: #99badd;"><span class="glyphicon glyphicon-comment" style="color: #99badd;"></span> 2</p>
                        </button>
                      <?php } ?>
                    </ul>
                    <h6 style="text-align: center; color: gray;">We can't win them all...</h6>
                </li>
            </ul>
            <!-- start example modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Prospect</h4>
                          </div>
                          <div class="modal-body">
                            <form>
                              <div class="form-group">
                                <label class="control-label">Customer Name:</label>
                                <input type="text" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="control-label">Nama Sales:</label>
                                <input type="text" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="control-label">Nama TL:</label>
                                <input type="text" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="control-label">Motor:</label>
                                <textarea class="form-control"></textarea>
                              </div>
                              <div class="form-group">
                                <label class="control-label">Warna:</label>
                                <input type="text" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="control-label">FINCOY:</label>
                                <input type="text" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="control-label">DP:</label>
                                <input type="text" class="form-control">
                              </div>
                            </form>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Create New</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  <!-- end modal -->
          <!-- start <li> modal -->
                    <div class="modal fade" id="ModalList" tabindex="-1" role="dialog" aria-labelledby="ModalListLabel">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Card Details</h4>
                            <h2 class="modal-title">Nama</h2>
                            <h4 class="modal-title" style="color: gray;">Created by Angga Pramana Putra on Feb 25, 2020 10:36 AM</h4>
                          </div>
                          <div class="modal-body">
                            <label class="control-label">Initial Form</label>
                            <div style="background-color: #F5F5F5; display: flex;">
                              <div style="margin: 40px;">
                                <div class="form-group">
                                  <label class="control-label">Customer Name</label><br>
                                  <label class="control-label" style="color: #808080">Angga Pramana</label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">Nama Sales</label><br>
                                  <label class="control-label" style="color: #808080">Pak Hamid</label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">Nama TL</label><br>
                                  <label class="control-label" style="color: #808080">Nama TL</label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">TL</label>
                                  <div class="row">
                                    <div class="col-md-1"><div class="square" style="margin-top: 5px;"></div></div>
                                    <label class="col-md-1 control-label" style="color: #808080;">Dewa</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">Motor</label><br>
                                  <label class="control-label" style="color: #808080">Nama Motor</label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">Warna</label><br>
                                  <label class="control-label" style="color: #808080">Nama Warna</label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">Fincoy</label><br>
                                  <label class="control-label" style="color: #808080">Nama Fincoy</label>
                                </div>
                                <div class="form-group">
                                  <label class="control-label">DP</label><br>
                                  <label class="control-label" style="color: #808080">5.000.000</label>
                                </div>
                              </div>
                              </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label">History</label>
                                  <div style="background-color: #F5F5F5; display: flex;">
                                  <div style="margin: 40px;">
                                    <div class="form-group">
                                      <div class="col-md-12">
                                      <label class="control-label">Yang belum survey</label><br>
                                      <label class="control-label" style="color: #808080">3 hours in this phase</label>
                                    </div>
                                    <div class="col-md-12" style="text-align: right;">
                                      <label class="control-label">02/25</label><br>
                                      <label class="control-label" style="color: #808080">10:36 AM</label>
                                    </div>
                                    </div>
                                  </div>
                              </div>
                                </div>
                                <div style="margin-top: 20px;">
                                  <label class="control-label">Comments</label>
                                  <div style="background-color: #F5F5F5; display: flex;">
                              <div style="margin: 40px;">
                                <div class="form-group">
                                  <div class="row">
                                    <div class="col-md-4">
                                         <div class="form-group">
                                            <div class="input-group">
                                            <input type="search" name="searchBy" id="searchBy" class="form-control" style="width: 450px;" />
                                            <span class="input-group-btn">
                                                <button id="filter" class="btn btn-primary btn-block" onclick="searchStationTable();">Post
                                                </button>
                                            </span>
                                            </div>
                                         </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              </div>
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Create New</button>
                          </div>
                        </div>
                      </div>
                    </div>

                  <!-- end modal -->
        <!-- </div> -->

        <!--<div class="row">
          <div class='col-lg-3'>
            <div class='small-box bg-red'>
              <div class='inner'><h3>Transaksi</h3><p><b></b></p></div>
              <div class='icon'><i class='fa fa-money'></i></div>
              <a href='<?php echo base_url('admin/invoice') ?>' class='small-box-footer'>Selengkapnya <i class='fa fa-arrow-circle-right'></i></a>
            </div>
          </div>
          <div class='col-lg-3'>
            <div class='small-box bg-blue'>
              <div class='inner'><h3>Pemilik</h3><p><b></b></p></div>
              <div class='icon'><i class='fa fa-users'></i></div>
              <a href='<?php echo base_url('admin/pemilik') ?>' class='small-box-footer'>Selengkapnya <i class='fa fa-arrow-circle-right'></i></a>
            </div>
          </div>
          <div class='col-lg-3'>
            <div class='small-box bg-blue'>
              <div class='inner'><h3>Penyewa</h3><p><b></b></p></div>
              <div class='icon'><i class='fa fa-users'></i></div>
              <a href='<?php echo base_url('admin/penyewa') ?>' class='small-box-footer'>Selengkapnya <i class='fa fa-arrow-circle-right'></i></a>
            </div>
          </div>
          <div class='col-lg-3'>
            <div class='small-box bg-green'>
              <div class='inner'><h3>Sawah</h3><p><b></b></p></div>
              <div class='icon'><i class='fa fa-money'></i></div>
              <a href='<?php echo base_url('admin/sawah') ?>' class='small-box-footer'>Selengkapnya <i class='fa fa-arrow-circle-right'></i></a>
            </div>
          </div>
        </div>-->
      <script src="<?php echo base_url() ?>assets/js/dragula.min.js"></script>
      <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
      <script type="text/javascript">

        dragula([
            document.getElementById('1'),
            document.getElementById('2'),
            document.getElementById('3'),
            document.getElementById('4'),
            document.getElementById('5'),
            document.getElementById('6')
        ])

        .on('drag', function(el) {
            
            // add 'is-moving' class to element being dragged
            el.classList.add('is-moving');
        })
        .on('dragend', function(el) {
            
            // remove 'is-moving' class from element after dragging has stopped
            el.classList.remove('is-moving');
            
            // add the 'is-moved' class for 600ms then remove it
            window.setTimeout(function() {
                el.classList.add('is-moved');
                window.setTimeout(function() {
                    el.classList.remove('is-moved');
                }, 600);
            }, 100);
        });


        var createOptions = (function() {
            var dragOptions = document.querySelectorAll('.drag-options');
            
            // these strings are used for the checkbox labels
            var options = ['Research', 'Strategy', 'Inspiration', 'Execution'];
            
            // create the checkbox and labels here, just to keep the html clean. append the <label> to '.drag-options'
            function create() {
                for (var i = 0; i < dragOptions.length; i++) {

                    options.forEach(function(item) {
                        var checkbox = document.createElement('input');
                        var label = document.createElement('label');
                        var span = document.createElement('span');
                        checkbox.setAttribute('type', 'checkbox');
                        span.innerHTML = item;
                        label.appendChild(span);
                        label.insertBefore(checkbox, label.firstChild);
                        label.classList.add('drag-options-label');
                        dragOptions[i].appendChild(label);
                    });

                }
            }
            
            return {
                create: create
            }
            
            
        }());

        var showOptions = (function () {
            
            // the 3 dot icon
            var more = document.querySelectorAll('.drag-header-more');
            
            function show() {
                // show 'drag-options' div when the more icon is clicked
                var target = this.getAttribute('data-target');
                var options = document.getElementById(target);
                options.classList.toggle('active');
            }
            
            
            function init() {
                for (i = 0; i < more.length; i++) {
                    more[i].addEventListener('click', show, false);
                }
            }
            
            return {
                init: init
            }
        }());

        createOptions.create();
        showOptions.init();
      </script>
      <script>
            $(function () {
                $('#date1').datetimepicker();
                $('#date2').datetimepicker({
                    useCurrent: false //Important! See issue #1075
                });
                $("#date1").on("dp.change", function (e) {
                    $('#date2').data("DateTimePicker").minDate(e.date);
                });
                $("#date2").on("dp.change", function (e) {
                    $('#date1').data("DateTimePicker").maxDate(e.date);
                });

            });
            
        </script>
       
      </section>