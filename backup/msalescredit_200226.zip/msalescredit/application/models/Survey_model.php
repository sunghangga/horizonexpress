<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Survey_model extends CI_Model
{

    public $table = 'survey_lists';
    public $id = 'sv_id';
    public $order = 'ASC';
    private $db_jmb;

    function __construct()
    {
        parent::__construct();
        $this->db_jmb = $this->load->database('jmb', TRUE);
    }

    function get_status($date,$status)
    {
        $this->db_jmb->where('sv_result', $status);
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    function get_count_status($date,$status)
    {
        $this->db_jmb->where('sv_result', $status);
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        return $this->db_jmb->count_all_results($this->table);
    }

    function get_pending($date)
    {
        $this->db_jmb->where('sv_result', NULL);
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    function get_count_pending($date)
    {
        $this->db_jmb->where('sv_result', NULL);
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        return $this->db_jmb->count_all_results($this->table);
    }

    function get_process($date)
    {
        $this->db_jmb->where('sv_result!=', NULL);
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    function get_count_process($date)
    {
        $this->db_jmb->where('sv_result!=', NULL);
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        return $this->db_jmb->count_all_results($this->table);
    }

    function get_acc($date)
    {
        $this->db_jmb->where('sv_result', 'ACC');
        $this->db_jmb->where('allproc!=', '1');
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    function get_count_acc($date)
    {
        $this->db_jmb->where('sv_result', 'ACC');
        $this->db_jmb->where('allproc!=', '1');
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        return $this->db_jmb->count_all_results($this->table);
    }

    function get_do($date)
    {
        $this->db_jmb->where('sv_result', 'ACC');
        $this->db_jmb->where('allproc', '1');
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    function get_count_do($date)
    {
        $this->db_jmb->where('sv_result', 'ACC');
        $this->db_jmb->where('allproc', '1');
        $this->db_jmb->where('sv_date', $date);
        $this->db_jmb->where('ori_code', 'JMB');
        return $this->db_jmb->count_all_results($this->table);
    }

    // get all
    function get_range($first,$last,$status)
    {
        if($status != 'ALL'){
          $this->db_jmb->where('sv_result', $status);
        }
        $this->db_jmb->where('sv_date>=', $first);
        $this->db_jmb->where('sv_date<=', $last);
        $this->db_jmb->where('ori_code', 'JMB');
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    function get_all()
    {
        $this->db_jmb->where('sv_date=', date('Y-m-d'));
        $this->db_jmb->order_by('sv_date', $this->order);
        return $this->db_jmb->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db_jmb->where($this->id, $id);
        return $this->db_jmb->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db_jmb->like('sv_id', $q);
	$this->db_jmb->or_like('sv_no', $q);
	$this->db_jmb->or_like('cust_code', $q);
	$this->db_jmb->or_like('slm_code', $q);
	$this->db_jmb->or_like('sv_result', $q);
	$this->db_jmb->or_like('cust_name', $q);
	$this->db_jmb->or_like('cust_idcardno', $q);
	$this->db_jmb->from($this->table);
        return $this->db_jmb->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db_jmb->order_by($this->id, $this->order);
        $this->db_jmb->like('sv_id', $q);
	$this->db_jmb->or_like('sv_no', $q);
	$this->db_jmb->or_like('cust_code', $q);
	$this->db_jmb->or_like('slm_code', $q);
	$this->db_jmb->or_like('sv_result', $q);
	$this->db_jmb->or_like('cust_name', $q);
	$this->db_jmb->or_like('cust_idcardno', $q);
	$this->db_jmb->limit($limit, $start);
        return $this->db_jmb->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db_jmb->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db_jmb->where($this->id, $id);
        $this->db_jmb->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db_jmb->where($this->id, $id);
        $this->db_jmb->delete($this->table);
    }

}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-08-16 13:59:02 */
/* http://harviacode.com */