<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Beranda extends CI_Controller
{
    
        
    function __construct()
    {
        parent::__construct();
        if($this->session->userdata('user_logedin') != 'TRUE'){ redirect('login', 'refresh');}
    }


    public function index()
    {
        $data = array(
            'tagihan' => '',
        );

        $this->template->load('template','beranda', $data);

    }
}