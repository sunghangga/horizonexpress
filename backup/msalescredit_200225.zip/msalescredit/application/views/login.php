<html>
<head>
    <title>M-Sales Credit</title>
    <link rel="stylesheet" href="<?php echo base_url() ?>template/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?echo base_url();?>public/css/style.css">
</head>
<body class="login-body" background="<?php echo base_url()?>assets/img/media-monitoring.jpg">
	<div style="display: table;height: 100%;width: 100%;">
		<div class="container" style="display: table-cell;padding-top:50px;">
			<div class="row">
				<div class="col-sm-6 col-md-4 col-md-offset-4">
					<?php if(isset($error)) { echo $error; }; ?>
					<div class="margin-autolr" style="background-color: #ffffffcf; border-radius:3px; padding: 15px;box-shadow: 0 6px 6px rgba(0,0,0,0.3)">
						<div class="text-center" >
							<p>
								<!--<img src="<?php echo base_url();?>assets/img/logo.jpg" height="100px" width="100px">-->
								<h4 style="color:#019fde"><b>M-Sales Credit</b> </h4>
						</div>
						
						<form style="padding-top:10px;" class="form-signin margint-10" method="POST" action="<?php echo base_url() ?>login/">
							<? log_message('error', base_url().'Login');?>
						<div class="form-group">
							<input type="text" class="form-control" name="username" id="username-id" placeholder="Username" autofocus>
							<?php echo form_error('username'); ?>
						</div>
						<div class="form-group">
							<input type="password" name="password" class="form-control" placeholder="Password">
							<?php echo form_error('password'); ?>
						</div>

							<button class="btn btn-lg btn-primary btn-block" style="border-radius: 0;" name="btn-login" id="btn-login" type="submit">
							Masuk</button>

						</form>
					</div>
					<div id="error" style="margin-top: 10px"></div>
				</div>
			</div>
		</div>
	</div>	
	<!-- jQuery 2.1.4 -->
	<script src="<?php echo base_url() ?>template/plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<!-- Bootstrap 3.3.5 -->
	<script src="<?php echo base_url() ?>template/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>