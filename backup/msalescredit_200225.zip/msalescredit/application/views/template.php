<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>M-Sales Credit</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Bootstrap 3.3.5 -->
        <link rel="stylesheet" href="<?php echo base_url() ?>template/bootstrap/css/bootstrap.min.css">
        <!-- Font Awesome -->
        <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">-->
        <link rel="stylesheet" href="<?php echo base_url() ?>template/font-awesome-4.4.0/css/font-awesome.min.css">
        <!-- Ionicons -->
        <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
        <link rel="stylesheet" href="<?php echo base_url() ?>template/ionicons-2.0.1/css/ionicons.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo base_url() ?>template/plugins/datatables/dataTables.bootstrap.css">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>template/dist/css/AdminLTE.min.css">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="<?php echo base_url() ?>template/dist/css/skins/_all-skins.min.css">
             <!--custom css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap-datepicker3.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap-datetimepicker.min.css">
		<!--Jquery-UI-->
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/jquery-ui.min.css">

        <link rel="stylesheet" href="<?php echo base_url('template/plugins/')?>jqueryui/jquery-ui.css">
        
    </head>
    <body class="hold-transition skin-blue-light sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <!-- Logo -->
                <a href="index2.html" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>MSC</b></span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg"><b>M-Sales Credit</b> </span>
                </a>
                <!-- Header Navbar: style can be found in header.less -->
                <nav class="navbar navbar-static-top" role="navigation">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">



                            <!-- User Account: style can be found in dropdown.less -->
                            <li class="dropdown user user-menu">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="<?php echo base_url()?>template/dist/img/avatar5.png" class="user-image" alt="User Image">
                                    <span class="hidden-xs"><?php echo $this->session->userdata('user_nama')?></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li class="user-header">
                                        <img src="<?php echo base_url()?>template/dist/img/avatar5.png" class="img-circle" alt="User Image">
                                        <p>
                                            <?php echo $this->session->userdata('user_nama')?>
                                        </p>
                                    </li>
                                    <li class="user-footer">
                                        <div class="pull-left">
                                            <?php
                                            echo anchor('user/profil','Profil',array('class'=>'btn btn-default btn-flat'));
                                            ?>
                                        </div>
                                        <div class="pull-right">
                                            <?php
                                            echo anchor('login/logout','Sing out',array('class'=>'btn btn-default btn-flat'));
                                            ?>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="main-sidebar">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li <?php if($this->uri->segment(1)=="beranda"){echo "class='active'";} ?>>
                            <a href="<?php echo base_url('beranda') ?>">
                              <i class="fa fa-home"></i> <span>Beranda</span>
                            </a>
                        </li>
                        <li <?php if($this->uri->segment(1)=="survey"){echo "class='active'";} ?>>
                            <a href="<?php echo base_url('survey') ?>">
                              <i class="fa fa-book"></i> <span>Survey</span>
                            </a>
                        </li>
                         <!-- <li <?php if($this->uri->segment(2) == "transaksi"){echo "class='active'";} ?>>
                            <a href='#'><i class='fa fa-newspaper-o'></i><span> Kelola Transaksi </span><i class='fa fa-angle-left pull-right'></i></a>
                            <ul class='treeview-menu'>
                              <li <?php if($this->uri->segment(2)=="transaksi" && $this->uri->segment(3) == "sudah"){echo "class='active'";} ?>>
                                <a href="<?php echo base_url('admin/transaksi/sudah') ?>">
                                  <i class="fa fa-circle-o"></i> <span>Sudah bayar</span>
                                </a>
                              </li>
                              <li <?php if($this->uri->segment(2)=="transaksi" && $this->uri->segment(3) == "belum"){echo "class='active'";} ?>>
                                <a href="<?php echo base_url('admin/transaksi/belum') ?>">
                                  <i class="fa fa-circle-o"></i> <span>Belum Bayar</span>
                                </a>
                              </li>
                            </ul>
                          </li>-->

                        <li <?php if($this->uri->segment(1) == "user" || $this->uri->segment(1) == "group"){echo "class='active'";} ?>>
                            <a href='#'><i class='fa fa-gear'></i><span> Setting </span><i class='fa fa-angle-left pull-right'></i></a>
                            <ul class='treeview-menu'>
                              <li <?php if($this->uri->segment(1)=="user"){echo "class='active'";} ?>>
                                <a href="<?php echo base_url('user') ?>">
                                  <i class="fa fa-user"></i> <span>Users</span>
                                </a>
                              </li>
                              <li <?php if($this->uri->segment(1)=="group"){echo "class='active'";} ?>>
                                <a href="<?php echo base_url('group') ?>">
                                  <i class="fa fa-group"></i> <span>Group</span>
                                </a>
                              </li>
                            </ul>
                          </li>
                         <!-- <li >
                            <a href="<?php echo base_url('login/logout') ?>">
                              <i class="fa fa-sign-out"></i> <span>Logout</span>
                            </a>
                        </li>-->
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    </ol>
                </section>


                <?php
                echo $contents;
                ?>



            </div><!-- /.content-wrapper -->
            <footer class="main-footer">
                <div class="pull-right hidden-xs">
                    <b>Version</b> 1.0.0
                </div>
                <strong>M-Sales Credit &copy; 2019</strong>	| Powered by MKM Honda Jimbaran
            </footer>

            <!-- Add the sidebar's background. This div must be placed
                 immediately after the control sidebar -->
            <div class="control-sidebar-bg"></div>
        </div><!-- ./wrapper -->

        <!-- jQuery 2.1.4 -->
        <script src="<?php echo base_url() ?>template/plugins/jQuery/jQuery-2.1.4.min.js"></script>
        <!-- Bootstrap 3.3.5 -->
        <script src="<?php echo base_url() ?>template/bootstrap/js/bootstrap.min.js"></script>
        <!-- DataTables -->
        <script src="<?php echo base_url() ?>template/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url() ?>template/plugins/datatables/dataTables.bootstrap.min.js"></script>
        <!-- SlimScroll -->
        <script src="<?php echo base_url() ?>template/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <!-- FastClick -->
        <script src="<?php echo base_url() ?>template/plugins/fastclick/fastclick.min.js"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url() ?>template/dist/js/app.min.js"></script>

        <script src="<?php echo base_url('template/plugins/')?>jqueryui/jquery-ui.js"></script>
        
        <script src="<?php echo base_url() ?>assets/bootstrap/js/moment.js"></script>
        <script src="<?php echo base_url() ?>assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url() ?>template/dist/js/demo.js"></script>

        
        
    </body>
</html>
