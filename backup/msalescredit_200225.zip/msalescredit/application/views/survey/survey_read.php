
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>Survey Read</h3>
        <table class="table table-bordered">
	    <tr><td>Buka Do</td><td><?php echo $buka_do; ?></td></tr>
	    <tr><td>Customer</td><td><?php echo $customer; ?></td></tr>
	    <tr><td>Date</td><td><?php echo $date; ?></td></tr>
	    <tr><td>Dp</td><td><?php echo $dp; ?></td></tr>
	    <tr><td>Fincoy</td><td><?php echo $fincoy; ?></td></tr>
	    <tr><td>Hasil Survey</td><td><?php echo $hasil_survey; ?></td></tr>
	    <tr><td>Indent Date</td><td><?php echo $indent_date; ?></td></tr>
	    <tr><td>Input Soda</td><td><?php echo $input_soda; ?></td></tr>
	    <tr><td>Motor</td><td><?php echo $motor; ?></td></tr>
	    <tr><td>Note</td><td><?php echo $note; ?></td></tr>
	    <tr><td>Rencana Do</td><td><?php echo $rencana_do; ?></td></tr>
	    <tr><td>Sales</td><td><?php echo $sales; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $status; ?></td></tr>
	    <tr><td>Sv No</td><td><?php echo $sv_no; ?></td></tr>
	    <tr><td>Tgl Survey</td><td><?php echo $tgl_survey; ?></td></tr>
	    <tr><td>Warna</td><td><?php echo $warna; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('survey') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->