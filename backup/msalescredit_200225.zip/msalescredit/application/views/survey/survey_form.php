<!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                
                  <h3 class='box-title'>SURVEY</h3>
                      <div class='box box-primary'>
        <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
	    <tr><td>Buka Do <?php echo form_error('buka_do') ?></td>
            <td><input type="text" class="form-control" name="buka_do" id="buka_do" placeholder="Buka Do" value="<?php echo $buka_do; ?>" />
        </td>
	    <tr><td>Customer <?php echo form_error('customer') ?></td>
            <td><input type="text" class="form-control" name="customer" id="customer" placeholder="Customer" value="<?php echo $customer; ?>" />
        </td>
	    <tr><td>Date <?php echo form_error('date') ?></td>
            <td><input type="text" class="form-control" name="date" id="date" placeholder="Date" value="<?php echo $date; ?>" />
        </td>
	    <tr><td>Dp <?php echo form_error('dp') ?></td>
            <td><input type="text" class="form-control" name="dp" id="dp" placeholder="Dp" value="<?php echo $dp; ?>" />
        </td>
	    <tr><td>Fincoy <?php echo form_error('fincoy') ?></td>
            <td><input type="text" class="form-control" name="fincoy" id="fincoy" placeholder="Fincoy" value="<?php echo $fincoy; ?>" />
        </td>
	    <tr><td>Hasil Survey <?php echo form_error('hasil_survey') ?></td>
            <td><input type="text" class="form-control" name="hasil_survey" id="hasil_survey" placeholder="Hasil Survey" value="<?php echo $hasil_survey; ?>" />
        </td>
	    <tr><td>Indent Date <?php echo form_error('indent_date') ?></td>
            <td><input type="text" class="form-control" name="indent_date" id="indent_date" placeholder="Indent Date" value="<?php echo $indent_date; ?>" />
        </td>
	    <tr><td>Input Soda <?php echo form_error('input_soda') ?></td>
            <td><input type="text" class="form-control" name="input_soda" id="input_soda" placeholder="Input Soda" value="<?php echo $input_soda; ?>" />
        </td>
	    <tr><td>Motor <?php echo form_error('motor') ?></td>
            <td><input type="text" class="form-control" name="motor" id="motor" placeholder="Motor" value="<?php echo $motor; ?>" />
        </td>
	    <tr><td>Note <?php echo form_error('note') ?></td>
            <td><textarea class="form-control" rows="3" name="note" id="note" placeholder="Note"><?php echo $note; ?></textarea>
        </td></tr>
	    <tr><td>Rencana Do <?php echo form_error('rencana_do') ?></td>
            <td><input type="text" class="form-control" name="rencana_do" id="rencana_do" placeholder="Rencana Do" value="<?php echo $rencana_do; ?>" />
        </td>
	    <tr><td>Sales <?php echo form_error('sales') ?></td>
            <td><input type="text" class="form-control" name="sales" id="sales" placeholder="Sales" value="<?php echo $sales; ?>" />
        </td>
	    <tr><td>Status <?php echo form_error('status') ?></td>
            <td><input type="text" class="form-control" name="status" id="status" placeholder="Status" value="<?php echo $status; ?>" />
        </td>
	    <tr><td>Sv No <?php echo form_error('sv_no') ?></td>
            <td><input type="text" class="form-control" name="sv_no" id="sv_no" placeholder="Sv No" value="<?php echo $sv_no; ?>" />
        </td>
	    <tr><td>Tgl Survey <?php echo form_error('tgl_survey') ?></td>
            <td><input type="text" class="form-control" name="tgl_survey" id="tgl_survey" placeholder="Tgl Survey" value="<?php echo $tgl_survey; ?>" />
        </td>
	    <tr><td>Warna <?php echo form_error('warna') ?></td>
            <td><input type="text" class="form-control" name="warna" id="warna" placeholder="Warna" value="<?php echo $warna; ?>" />
        </td>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('survey') ?>" class="btn btn-default">Cancel</a></td></tr>
	
    </table></form>
    </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->