/*
SQLyog Community
MySQL - 8.0.17 : Database - mkmhonda_msc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `mkmhonda_msc`;

/*Table structure for table `comment` */

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` mediumtext NOT NULL,
  `suryvey_id` varchar(25) NOT NULL,
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `comment` */

/*Table structure for table `group` */

DROP TABLE IF EXISTS `group`;

CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `group` */

insert  into `group`(`id`,`name`) values 
(1,'Admin'),
(2,'Marketing'),
(3,'PIC'),
(4,'Owner');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(55) NOT NULL,
  `kelamin` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pria',
  `username` varchar(55) NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `group_id` int(11) NOT NULL,
  `status` int(5) NOT NULL DEFAULT '1',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`nama`,`kelamin`,`username`,`password`,`group_id`,`status`,`create_at`,`update_at`) values 
(1,'Hamid','l','superadmin','$2a$08$StFwtkJWEwtEgmzF4Q8j/.Ddz2iGnFzipQtrsYe4rrSGjTB4PBF3G',1,1,'2020-02-22 10:32:39','2020-02-22 11:02:18'),
(2,'Wawan','pria','wawan','$2a$08$xNDHiQWlJxAi.5xqscbgdeBkb1PSfYBTMF8tGKL8EaFxFR3HH.BeG',3,1,'2020-02-22 11:57:05','2020-02-22 10:02:59'),
(3,'SUWARI','pria','suwari','$2a$08$XRyE3AQMbQGemTYonnsa2.2.JhRcovZ.SCmOSJtdXTCB9DPFmf3OG',2,1,'2020-02-22 11:59:48','2020-02-22 11:02:06');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
